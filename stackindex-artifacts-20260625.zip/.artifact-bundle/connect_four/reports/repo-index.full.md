# StackIndex Full Repo Index

Generated: 2026-06-25 11:33:59

This is the verbose companion to `repo-index.md`. Use it when the compact search plan is not enough.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `connect_four`
- Path: `/Users/will/Workspace/connect_four`
- Files indexed: 55
- Finding summary: 0 high, 0 medium, 3 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 5
- Large files skipped: 0
- Binary files skipped: 40
- Unresolved internal imports: 0
- Internal alias imports resolved: 0
- Confidence warnings:
  - Binary files were skipped.

## Project Context

- Likely purpose: Board-game/game arena application
- Confidence: high
- README title: BoardArena
- README summary: BoardArena is a local-first AI board-game arena built with React, Vite, TypeScript, and FastAPI. It is designed as a portfolio-ready full-stack app: the frontend delivers a polished multi-game experience, while the backend owns game sessions, legal move validation, state transitions, scoring, and AI move selection.
- Evidence:

  - README/package metadata points to board-game/game arena application.
  - Package scripts include frontend:build, frontend:dev, frontend:test:smoke, smoke:production.
  - Environment variable names include ALLOWED_ORIGINS, APP_ENV, CI, DEV.
  - API routes include ai, backend, games, health endpoints.
  - Repository structure includes backend/ for backend service.

## Feature Map

### Games

- Start here:
  - `backend/app/api/routes/games.py`
  - `frontend/src/api/games.ts`
  - `backend/app/schemas/game.py`
  - `backend/app/services/game_manager.py`
  - `backend/game/__init__.py`
  - `backend/game/ai.py`
  - `backend/game/connect4.py`
  - `backend/game/reversi.py`
  - `backend/game/reversi_ai.py`
  - `backend/game/tictactoe.py`
  - `backend/game/tictactoe_ai.py`
  - `frontend/src/games/connect4/types.ts`
  - `frontend/src/games/registry.ts`
- Related tests: none detected
- Search terms: `game`, `games`, `match`, `moves`
- Routes: `GET /games/{game_id}`, `POST /games`, `POST /games/{game_id}/moves/ai`, `POST /games/{game_id}/moves/human`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Backend services

- Start here:
  - `backend/app/services/__init__.py`
  - `backend/app/services/ai_service.py`
  - `backend/app/services/game_manager.py`
- Related tests: none detected
- Search terms: `backend-service`, `service`, `services`, `backend`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### AI moves

- Start here:
  - `backend/app/api/routes/games.py`
- Related tests: none detected
- Search terms: `ai-move`, `ai`, `move`, `moves`, `human`
- Routes: `POST /games/{game_id}/moves/ai`, `POST /games/{game_id}/moves/human`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Frontend game UI

- Start here:
  - `frontend/src/components/ConnectFourBoard.tsx`
  - `frontend/src/components/ReversiBoard.tsx`
  - `frontend/src/components/TicTacToeBoard.tsx`
- Related tests: none detected
- Search terms: `frontend-game-ui`, `frontend`, `board`, `ui`, `game`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Health

- Start here:
  - `backend/app/main.py`
- Related tests: none detected
- Search terms: `health`
- Routes: `GET /_backend/api/health`, `GET /_backend/health`, `GET /api/health`, `GET /health`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Backend

- Start here:
  - `backend/app/main.py`
- Related tests: none detected
- Search terms: `backend`
- Routes: `GET /_backend/api/health`, `GET /_backend/health`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Init

- Start here:
  - `backend/app/api/__init__.py`
  - `backend/app/__init__.py`
- Related tests: none detected
- Search terms: `init`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: low

### Smoke

- Start here:
  - `scripts/smoke-production.mjs`
- Related tests:
  - `frontend/tests/smoke.spec.ts`
- Search terms: `smoke`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: low

## Task Search Recipes

### Fix API Behavior

1. Open the matching file in API Routes or Route Implementation Chains.
2. Follow the listed imports into shared `src/lib/`, database, schema, or validation files.
3. Open the nearest related test from Feature Map or Route Implementation Chains.
4. Broaden to whole-repo search only after route, schema, storage, and tests are checked.

### Fix UI Behavior

1. Start from the matching `src/app/<feature>/page.*` or sibling component in Feature Map.
2. Search inside that feature folder and matching `src/lib/<feature>/` before shared modules.
3. Check API calls and route handlers before editing shared database code.
4. Avoid global styles/assets unless the task is visual or layout-specific.

### Fix Env Or Deployment Issue

1. Open `.env.example` if present.
2. Open env/config files from Key Files or Feature Map.
3. Check deployment docs, migrations, and package scripts.
4. Avoid unrelated feature files unless they reference the specific env var.

## Route Implementation Chains

- `GET /_backend/api/health`
  - Follow:
    - `backend/app/main.py`
- `GET /_backend/health`
  - Follow:
    - `backend/app/main.py`
- `GET /api/health`
  - Follow:
    - `backend/app/main.py`
- `POST /games`
  - Follow:
    - `backend/app/api/routes/games.py`
- `GET /games/{game_id}`
  - Follow:
    - `backend/app/api/routes/games.py`
- `POST /games/{game_id}/moves/ai`
  - Follow:
    - `backend/app/api/routes/games.py`
- `POST /games/{game_id}/moves/human`
  - Follow:
    - `backend/app/api/routes/games.py`
- `GET /health`
  - Follow:
    - `backend/app/main.py`

## Agent Search Guide

- Read first:
  - `package.json` - Node package manifest and scripts
  - `README.md` - Project documentation
  - `frontend/tests/smoke.spec.ts`
  - `backend/app/api/routes/games.py` - API route handler
  - `vercel.json` - Vercel deployment config
  - `backend/app/main.py` - Health endpoint implementation
  - `scripts/smoke-production.mjs` - Operational validation script
- Search by directory role:
  - `backend/` - Backend service
  - `backend/app/` - Backend application code
  - `backend/app/api/` - Backend API routes
  - `frontend/` - Frontend app
  - `frontend/src/` - Frontend source code
  - `scripts/` - Operational scripts/tooling
- Inspect dependency hubs before leaf files:
  - `frontend/src/App.tsx` - imports 7 internal file(s), imported by 1 internal file(s)
  - `frontend/src/games/connect4/types.ts` - imports 0 internal file(s), imported by 7 internal file(s)
  - `frontend/src/api/games.ts` - imports 1 internal file(s), imported by 1 internal file(s)
  - `frontend/src/components/ConnectFourBoard.tsx` - imports 1 internal file(s), imported by 1 internal file(s)
  - `frontend/src/components/ReversiBoard.tsx` - imports 1 internal file(s), imported by 1 internal file(s)

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For API behavior, start from the API Routes section and follow imports from each route file.
- For configuration questions, inspect the Environment Variables section before opening env-related files.
- For expected behavior, use the Tests section to find representative test files and scripts.
- For risk review, start with Findings; each item names the category and usually the relevant file.

## Changes Since Previous Snapshot

- Previous snapshot: `20260625-031729`
- Current generated: `2026-06-25 11:33:59`
- Audit status: `not run` -> `not run`

- Routes changed: 0 added, 3 removed.

- Added routes: none
- Removed routes: `GET /{game_id}`, `POST /{game_id}/moves/ai`, `POST /{game_id}/moves/human`
- Added env vars: none
- Removed env vars: none
- Added findings: none
- Resolved findings: none
- Stack changes: none
- Framework changes: none
- Database changes: none
- Test signal changes: none
- Deployment signal changes: none
- Key file changes: none

## Detected Stack

- Languages: Python, TypeScript, JavaScript
- Frameworks: FastAPI, Vite, React, Node.js
- Libraries: none detected
- Databases: none detected
- Testing: Playwright
- Deployment: Vercel

## Project Structure

- `backend/` — Backend service. 25 files scanned.
- `backend/app/` — Backend application code. 11 files scanned.
- `backend/app/api/` — Backend API routes. 3 files scanned.
- `frontend/` — Frontend app. 21 files scanned.
- `frontend/src/` — Frontend source code. 11 files scanned.
- `scripts/` — Operational scripts/tooling. 2 files scanned.
- `docs/` — Documentation. 1 files scanned.

## Key Files

- `README.md` — Project documentation.
- `backend/app/main.py` — Health endpoint implementation.
- `package.json` — Node package manifest and scripts.
- `vercel.json` — Vercel deployment config.
- `backend/app/api/routes/games.py` — API route handler.
- `scripts/smoke-production.mjs` — Operational validation script.

## File Connections

- `frontend/src/App.tsx` — frontend entrypoint/component; Coordinates several internal modules; imports 7 internal file(s), imported by 1 internal file(s).
- `frontend/src/games/connect4/types.ts` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 7 internal file(s).
- `frontend/src/api/games.ts` — source file; Connected to the internal dependency graph; imports 1 internal file(s), imported by 1 internal file(s).
- `frontend/src/components/ConnectFourBoard.tsx` — source file; Connected to the internal dependency graph; imports 1 internal file(s), imported by 1 internal file(s).
- `frontend/src/components/ReversiBoard.tsx` — source file; Connected to the internal dependency graph; imports 1 internal file(s), imported by 1 internal file(s).
- `frontend/src/components/TicTacToeBoard.tsx` — source file; Connected to the internal dependency graph; imports 1 internal file(s), imported by 1 internal file(s).
- `frontend/src/games/registry.ts` — source file; Connected to the internal dependency graph; imports 1 internal file(s), imported by 1 internal file(s).
- `frontend/src/lib/gameCopy.ts` — source file; Connected to the internal dependency graph; imports 1 internal file(s), imported by 1 internal file(s).
- `frontend/src/main.tsx` — frontend entrypoint/component; Connected to the internal dependency graph; imports 1 internal file(s), imported by 0 internal file(s).
- `scripts/smoke-production.mjs` — operational validation script; Connected to the internal dependency graph; imports 0 internal file(s), imported by 0 internal file(s).

## Important Exports

- `backend/app/api/routes/games.py`
  - `create_game` (function)
  - `get_game` (function)
  - `make_ai_move` (function)
  - `make_human_move` (function)
- `backend/app/main.py`
  - `api_healthcheck` (function)
  - `health_payload` (function)
  - `healthcheck` (function)
  - `prefixed_api_healthcheck` (function)
  - `prefixed_healthcheck` (function)
- `backend/app/services/game_manager.py`
  - `GameEngine` (class)
  - `GameSession` (class)
  - `InMemoryGameStore` (class)
- `backend/app/schemas/game.py`
  - `AIMetadata` (class)
  - `BoardCell` (class)
  - `ErrorResponse` (class)
  - `GameStateResponse` (class)
  - `HistoryMove` (class)
  - `MoveRequest` (class)
  - `MoveResponse` (class)
  - `NewGameRequest` (class)
- `backend/app/services/ai_service.py`
  - `AIService` (class)
- `frontend/src/api/games.ts`
  - `createGame` (function)
  - `makeAiMove` (function)
  - `makeHumanCellMove` (function)
  - `makeHumanMove` (function)
- `frontend/src/components/ConnectFourBoard.tsx`
  - `ConnectFourBoard` (function)
- `frontend/src/components/ReversiBoard.tsx`
  - `ReversiBoard` (function)
- `frontend/src/components/TicTacToeBoard.tsx`
  - `TicTacToeBoard` (function)
- `frontend/src/games/connect4/types.ts`
  - `AiMetadata` (type)
  - `AiStrategy` (type)
  - `BoardCell` (type)
  - `GameMode` (type)
  - `GameState` (type)
  - `GameType` (type)
  - `HistoryItem` (type)
  - `MoveResponse` (type)
- `frontend/src/games/registry.ts`
  - `gameName` (function)
  - `GameCatalogItem` (type)
  - `gameCatalog` (value)
  - `playableGames` (value)
- `backend/app/config.py`
  - `Settings` (class)
  - `get_settings` (function)

## File Overview

- Source files: 36
- Config files: 12
- Test files: 1
- Docs: 3

## Package Scripts

- `frontend:build`: `vite build`
- `frontend:dev`: `vite --host 127.0.0.1`
- `frontend:preview`: `vite preview --host 127.0.0.1`
- `frontend:test:smoke`: `playwright test`
- `frontend:typecheck`: `tsc --noEmit`
- `smoke:production`: `node scripts/smoke-production.mjs`
- `validate:local`: `node scripts/validate-local.mjs`

## Environment Variables

- `.env.example`: yes

- Required app config: `VITE_API_BASE_URL`
- Optional app config: `DEV` (missing from `.env.example`)
- Platform/build metadata: `CI` (detected but likely platform/build provided)
- Script-only vars: `PUBLIC_API_BASE_URL` (missing from `.env.example`), `PUBLIC_FRONTEND_URL` (missing from `.env.example`)
- Missing required from .env.example: none

## API Routes

- `GET /_backend/api/health` in `backend/app/main.py` (medium confidence; FastAPI route decorator.)
- `GET /_backend/health` in `backend/app/main.py` (medium confidence; FastAPI route decorator.)
- `GET /api/health` in `backend/app/main.py` (medium confidence; FastAPI route decorator.)
- `POST /games` in `backend/app/api/routes/games.py` (medium confidence; FastAPI route decorator.)
- `GET /games/{game_id}` in `backend/app/api/routes/games.py` (medium confidence; FastAPI route decorator.)
- `POST /games/{game_id}/moves/ai` in `backend/app/api/routes/games.py` (medium confidence; FastAPI route decorator.)
- `POST /games/{game_id}/moves/human` in `backend/app/api/routes/games.py` (medium confidence; FastAPI route decorator.)
- `GET /health` in `backend/app/main.py` (medium confidence; FastAPI route decorator.)

## Tests

- Test files: yes
- Test script: no
- Frameworks: Playwright

## Deployment Readiness

- README: yes
- `.env.example`: yes
- Dockerfile: no
- Vercel config: yes
- Health endpoint: yes
- Migration files: no

## Findings

- **low / tests**: Test tooling is installed, but no test script was found. (`package.json`)
  Recommendation: Add a test script that runs the configured test framework.
- **low / package**: No lint script found. (`package.json`)
  Recommendation: Add a lint script for local and CI readiness.
- **low / tests**: Test files exist, but no package test script was found. (`package.json`)
  Recommendation: Add a test script so tests are easy to run locally and in CI.

## Recommended Next Steps

- **low / tests**: Add a test script that runs the configured test framework.
- **low / package**: Add a lint script for local and CI readiness.
- **low / tests**: Add a test script so tests are easy to run locally and in CI.
