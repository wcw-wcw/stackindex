StackIndex artifacts for connect_four
Source: /Users/will/Workspace/connect_four/.stackindex
Included when present: analysis.json, AGENTS.md, reports/repo-index.md, reports/repo-index.full.md
