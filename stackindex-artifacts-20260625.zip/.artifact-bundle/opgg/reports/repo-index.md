# StackIndex Repo Index

Generated: 2026-06-25 11:34:00

This compact file is an agent-facing search plan. Read it before broad file searches so follow-up exploration can stay targeted. Open `repo-index.full.md` only when you need verbose routes, env vars, scripts, findings, or file counts.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `opgg`
- Path: `/Users/will/Workspace/opgg`
- Files indexed: 7
- Finding summary: 0 high, 0 medium, 2 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 4
- Large files skipped: 0
- Binary files skipped: 0
- Unresolved internal imports: 0
- Internal alias imports resolved: 0

## Feature Map Quality

- Feature map confidence: low
- Reason: Feature Map has fewer than 2 useful compact features; use Agent Search Guide and Key Files first.
- Start with Agent Search Guide and Key Files before broad searches.

## Small Project Guidance

- Read README, package metadata, and the main entrypoint first.
- Broad search is acceptable after checking Key Files.
- Use `repo-index.full.md` only if the compact index is not enough.

## Project Context

- Likely purpose: OP.GG-style stats dashboard
- Confidence: high
- README title: Local.GG
- README summary: A local OP.GG-style League of Legends stats dashboard. It currently uses mock data only, so it runs without a Riot API key or external requests.
- Evidence:

  - README/package metadata points to op.gg-style stats dashboard.
  - Package scripts include build, dev.
  - Repository structure includes src/ for frontend/source application code.

## Task Search Recipes

### Fix UI Behavior

1. Start from the matching `src/app/<feature>/page.*` or sibling component in Feature Map.
2. Search inside that feature folder and matching `src/lib/<feature>/` before shared modules.
3. Check API calls and route handlers before editing shared database code.
4. Avoid global styles/assets unless the task is visual or layout-specific.

## Agent Search Guide

- Read first:
  - `package.json` - Node package manifest and scripts
  - `README.md` - Project documentation
  - `src/main.jsx` - Frontend application entrypoint
- Search by directory role:
  - `src/` - Frontend/source application code
- Inspect dependency hubs before leaf files:
  - `src/main.jsx` - imports 0 internal file(s), imported by 0 internal file(s)

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For risk review, start with Findings; each item names the category and usually the relevant file.

## Changes Since Previous Snapshot

- Previous snapshot: `20260625-031729`
- Current generated: `2026-06-25 11:34:00`
- Audit status: `not run` -> `not run`

- No deterministic changes were detected since the previous snapshot.

- Added routes: none
- Removed routes: none
- Added env vars: none
- Removed env vars: none
- Added findings: none
- Resolved findings: none
- Stack changes: none
- Framework changes: none
- Database changes: none
- Test signal changes: none
- Deployment signal changes: none
- Key file changes: none

## Detected Stack

- Languages: JavaScript, TypeScript
- Frameworks: Vite, React, Node.js
- Libraries: none detected
- Databases: none detected
- Testing: none detected
- Deployment: none detected

## Project Structure

- `src/` — Frontend/source application code. 2 files scanned.

## Key Files

- `README.md` — Project documentation.
- `package.json` — Node package manifest and scripts.
- `src/main.jsx` — Frontend application entrypoint.

## File Connections

- `src/main.jsx` — frontend application entrypoint; Connected to the internal dependency graph; imports 0 internal file(s), imported by 0 internal file(s).

## Architecture Hints

- This project appears mostly frontend/static based on Vite-style entrypoints and no detected API routes.

## Recommended Next Steps

- **low / package**: Add a lint script for local and CI readiness.
- **low / tests**: Add a small smoke test or unit test suite for the critical path.
