StackIndex artifacts for opgg
Source: /Users/will/Workspace/opgg/.stackindex
Included when present: analysis.json, AGENTS.md, reports/repo-index.md, reports/repo-index.full.md
