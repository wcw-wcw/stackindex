StackIndex artifacts for algo
Source: /Users/will/Workspace/algo/.stackindex
Included when present: analysis.json, AGENTS.md, reports/repo-index.md, reports/repo-index.full.md
