# StackIndex Full Repo Index

Generated: 2026-06-25 11:34:01

This is the verbose companion to `repo-index.md`. Use it when the compact search plan is not enough.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `algo`
- Path: `/Users/will/Workspace/algo`
- Files indexed: 5
- Finding summary: 0 high, 0 medium, 1 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 2
- Large files skipped: 0
- Binary files skipped: 0
- Unresolved internal imports: 0
- Internal alias imports resolved: 0

## Feature Map Quality

- Feature map confidence: low
- Reason: Feature Map has fewer than 2 useful compact features; use Agent Search Guide and Key Files first.
- Start with Agent Search Guide and Key Files before broad searches.

## Small Project Guidance

- Read README, package metadata, and the main entrypoint first.
- Broad search is acceptable after checking Key Files.
- Use `repo-index.full.md` only if the compact index is not enough.

## Project Context

- Likely purpose: Sorting visualizer
- Confidence: low
- README title: Sorting Visualizer
- README summary: A local, dependency-free sorting visualizer for CSV files full of numbers.
- Evidence:

  - README/package metadata suggests this broad purpose, but evidence was not strong enough for a high-confidence domain label.

## Task Search Recipes

## Agent Search Guide

- Read first:
  - `README.md` - Project documentation
  - `src/app.js` - Frontend application entrypoint
- Search by directory role:
  - `src/` - Frontend/source application code
- Inspect dependency hubs before leaf files:
  - `src/app.js` - imports 0 internal file(s), imported by 0 internal file(s)

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For risk review, start with Findings; each item names the category and usually the relevant file.

## Changes Since Previous Snapshot

- Previous snapshot: `20260625-031729`
- Current generated: `2026-06-25 11:34:01`
- Audit status: `not run` -> `not run`

- No deterministic changes were detected since the previous snapshot.

- Added routes: none
- Removed routes: none
- Added env vars: none
- Removed env vars: none
- Added findings: none
- Resolved findings: none
- Stack changes: none
- Framework changes: none
- Database changes: none
- Test signal changes: none
- Deployment signal changes: none
- Key file changes: none

## Detected Stack

- Languages: JavaScript
- Frameworks: none detected
- Libraries: none detected
- Databases: none detected
- Testing: none detected
- Deployment: none detected

## Project Structure

- `src/` — Frontend/source application code. 1 files scanned.

## Key Files

- `README.md` — Project documentation.
- `src/app.js` — Frontend application entrypoint.

## File Connections

- `src/app.js` — frontend application entrypoint; Connected to the internal dependency graph; imports 0 internal file(s), imported by 0 internal file(s).

## File Overview

- Source files: 1
- Config files: 1
- Test files: 0
- Docs: 1

## Package Scripts

No package scripts detected.

## Environment Variables

No environment variable usage detected.

## API Routes

No API routes detected.

## Tests

- Test files: no
- Test script: no
- Frameworks: none detected

## Deployment Readiness

- README: yes
- `.env.example`: no
- Dockerfile: no
- Vercel config: no
- Health endpoint: no
- Migration files: no

## Findings

- **low / tests**: No obvious test files were found.
  Recommendation: Add a small smoke test or unit test suite for the critical path.

## Recommended Next Steps

- **low / tests**: Add a small smoke test or unit test suite for the critical path.
