StackIndex artifacts for dfgen
Source: /Users/will/Workspace/dfgen/.stackindex
Included when present: analysis.json, AGENTS.md, reports/repo-index.md, reports/repo-index.full.md
