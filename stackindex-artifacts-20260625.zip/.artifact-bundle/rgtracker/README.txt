StackIndex artifacts for rgtracker
Source: /Users/will/Workspace/rgtracker/.stackindex
Included when present: analysis.json, AGENTS.md, reports/repo-index.md, reports/repo-index.full.md
