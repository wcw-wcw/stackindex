StackIndex artifacts for stkapp
Source: /Users/will/Workspace/stkapp/.stackindex
Included when present: analysis.json, AGENTS.md, reports/repo-index.md, reports/repo-index.full.md
