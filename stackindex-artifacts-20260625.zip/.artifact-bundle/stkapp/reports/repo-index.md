# StackIndex Repo Index

Generated: 2026-06-25 11:34:00

This compact file is an agent-facing search plan. Read it before broad file searches so follow-up exploration can stay targeted. Open `repo-index.full.md` only when you need verbose routes, env vars, scripts, findings, or file counts.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `stkapp`
- Path: `/Users/will/Workspace/stkapp`
- Files indexed: 144
- Finding summary: 0 high, 0 medium, 0 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 5
- Large files skipped: 0
- Binary files skipped: 1
- Unresolved internal imports: 0
- Internal alias imports resolved: 195
- Confidence warnings:
  - Binary files were skipped.

## Project Context

- Likely purpose: Stock monitoring and alerting application
- Confidence: high
- README title: SignalDesk
- README summary: SignalDesk is a local-first stock monitoring and alerting MVP. It lets a signed-in user maintain a small watchlist, create rule-based alerts, inspect chart data, replay candle datasets, and test notification flows. It is a research and planning tool only: it does not provide financial advice, connect to brokerage accounts, or execute trades.
- Evidence:

  - README/package metadata points to stock monitoring and alerting application.
  - Package scripts include build, db:migrate:postgres, dev, health:check.
  - Environment variable names include ALPACA_API_KEY_ID, ALPACA_API_SECRET_KEY, ALPACA_DATA_FEED, ALPACA_TRADING_BASE_URL.
  - API routes include auth, backtest, bars, channels, cleanup, datasets endpoints.
  - Repository structure includes db/migrations/ for database schema migration files.

## Feature Map

### Rules / alerts

- Start here:
  - `src/app/api/rules/[id]/route.ts`
  - `src/app/api/rules/backtest/route.ts`
  - `src/app/api/rules/preview/route.ts`
  - `src/app/api/rules/route.ts`
  - `src/app/api/rules/validate/route.ts`
  - `src/app/rules/[id]/page.tsx`
  - `src/app/rules/new/page.tsx`
  - `src/app/rules/page.tsx`
- Related tests:
  - `src/lib/rules/evaluate.test.ts`
- Search terms: `rule`, `rules`, `alert`, `alerts`, `condition`, `operator`
- Routes: `DELETE /api/rules/:id`, `GET /api/rules`, `PATCH /api/rules/:id`, `POST /api/rules`, `POST /api/rules/backtest`, `POST /api/rules/preview`, `POST /api/rules/validate`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Market data

- Start here:
  - `src/app/api/market/bars/[symbol]/route.ts`
  - `src/app/api/market/diagnostics/route.ts`
  - `src/app/api/market/snapshot/[symbol]/route.ts`
  - `src/app/api/market/status/route.ts`
  - `src/lib/market/alpaca-market-data.ts`
  - `src/lib/market/chart-bars.ts`
  - `src/lib/market/diagnostics.ts`
  - `src/lib/market/indicators.ts`
- Related tests:
  - `src/app/api/market/bars/[symbol]/route.test.ts`
  - `src/lib/market/alpaca-market-data.test.ts`
  - `src/lib/market/chart-bars.test.ts`
  - `src/lib/market/mock-market-data.test.ts`
  - `src/lib/market/provider.test.ts`
- Search terms: `market`, `quote`, `quotes`, `ticker`, `symbol`, `candle`
- Routes: `GET /api/market/bars/:symbol`, `GET /api/market/diagnostics`, `GET /api/market/snapshot/:symbol`, `GET /api/market/status`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Notifications

- Start here:
  - `src/app/api/notifications/channels/[id]/route.ts`
  - `src/app/api/notifications/channels/[id]/test/route.ts`
  - `src/app/api/notifications/channels/route.ts`
  - `src/app/api/notifications/phone/start/route.ts`
  - `src/app/api/notifications/phone/verify/route.ts`
  - `src/app/api/notifications/preferences/route.ts`
  - `src/lib/notifications/notification-service.ts`
  - `src/app/settings/notification-settings.tsx`
- Related tests:
  - `src/lib/notifications/notification-service.test.ts`
- Search terms: `notification`, `notifications`, `email`, `webhook`
- Routes: `DELETE /api/notifications/channels/:id`, `GET /api/notifications/channels`, `GET /api/notifications/preferences`, `PATCH /api/notifications/channels/:id`, `PATCH /api/notifications/preferences`, `POST /api/notifications/channels`, `POST /api/notifications/channels/:id/test`, `POST /api/notifications/phone/start`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Worker

- Start here:
  - `src/app/api/worker/replay/route.ts`
  - `src/app/api/worker/start/route.ts`
  - `src/app/api/worker/status/route.ts`
  - `src/app/api/worker/stop/route.ts`
  - `src/app/api/worker/tick/route.ts`
  - `src/lib/worker/live-monitor.ts`
  - `src/lib/worker/local-mock-worker.ts`
  - `src/lib/worker/local-worker-loop.ts`
- Related tests:
  - `src/lib/worker/live-monitor.test.ts`
  - `src/lib/worker/status.test.ts`
- Search terms: `worker`, `tick`, `job`, `cron`, `queue`
- Routes: `GET /api/worker/status`, `POST /api/worker/replay`, `POST /api/worker/start`, `POST /api/worker/stop`, `POST /api/worker/tick`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Auth

- Start here:
  - `src/app/api/auth/login/route.ts`
  - `src/app/api/auth/logout/route.ts`
  - `src/app/api/auth/me/route.ts`
  - `src/app/api/auth/register/route.ts`
  - `src/app/login/page.tsx`
  - `src/lib/auth/password.ts`
  - `src/lib/auth/rate-limit.ts`
  - `src/lib/auth/require-user.ts`
- Related tests: none detected
- Search terms: `auth`, `session`, `cookie`, `login`, `logout`
- Routes: `GET /api/auth/me`, `POST /api/auth/login`, `POST /api/auth/logout`, `POST /api/auth/register`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Watchlist

- Start here:
  - `src/app/api/watchlist/[symbol]/route.ts`
  - `src/app/api/watchlist/route.ts`
  - `src/app/watchlist/page.tsx`
  - `src/app/watchlist/watchlist-editor.tsx`
- Related tests: none detected
- Search terms: `watchlist`, `watchlists`, `symbol`, `ticker`
- Routes: `DELETE /api/watchlist/:symbol`, `GET /api/watchlist`, `POST /api/watchlist`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Symbol levels

- Start here:
  - `src/app/api/symbol-levels/[id]/route.ts`
  - `src/app/api/symbol-levels/route.ts`
  - `src/lib/symbol-levels.ts`
  - `src/app/symbols/[symbol]/symbol-levels-panel.tsx`
- Related tests:
  - `src/app/api/symbol-levels/[id]/route.test.ts`
  - `src/app/api/symbol-levels/route.test.ts`
- Search terms: `symbol-level`, `symbol`, `symbols`, `levels`, `targets`
- Routes: `DELETE /api/symbol-levels/:id`, `GET /api/symbol-levels`, `PATCH /api/symbol-levels/:id`, `POST /api/symbol-levels`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Replay

- Start here:
  - `src/app/api/replay/datasets/[id]/route.ts`
  - `src/app/api/replay/datasets/route.ts`
  - `src/app/api/worker/replay/route.ts`
  - `src/app/replay/page.tsx`
  - `src/lib/replay/candle-dataset.ts`
  - `src/app/replay/replay-lab.tsx`
- Related tests:
  - `src/lib/replay/candle-dataset.test.ts`
- Search terms: `replay`
- Routes: `DELETE /api/replay/datasets/:id`, `GET /api/replay/datasets`, `POST /api/replay/datasets`, `POST /api/worker/replay`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

## Task Search Recipes

### Fix API Behavior

1. Open the matching file in API Routes or Route Implementation Chains.
2. Follow the listed imports into shared `src/lib/`, database, schema, or validation files.
3. Open the nearest related test from Feature Map or Route Implementation Chains.
4. Broaden to whole-repo search only after route, schema, storage, and tests are checked.

### Fix UI Behavior

1. Start from the matching `src/app/<feature>/page.*` or sibling component in Feature Map.
2. Search inside that feature folder and matching `src/lib/<feature>/` before shared modules.
3. Check API calls and route handlers before editing shared database code.
4. Avoid global styles/assets unless the task is visual or layout-specific.

### Fix Env Or Deployment Issue

1. Open `.env.example` if present.
2. Open env/config files from Key Files or Feature Map.
3. Check deployment docs, migrations, and package scripts.
4. Avoid unrelated feature files unless they reference the specific env var.

### Debug Worker Or Scheduled Job

1. Start from worker entries in Feature Map or Key Files.
2. Follow imports into shared config, repositories, and domain logic.
3. Check scripts and tests that mention worker, tick, queue, cron, or sync.
4. Broaden only after the worker entrypoint and its direct dependencies are understood.

## Route Implementation Chains

- `POST /api/auth/login`
  - Follow:
    - `src/app/api/auth/login/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/password.ts`
    - `src/lib/auth/rate-limit.ts`
    - `src/lib/auth/session.ts`
- `POST /api/auth/logout`
  - Follow:
    - `src/app/api/auth/logout/route.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/db/postgres-repositories.ts`
    - `src/lib/db/provider.ts`
- `GET /api/auth/me`
  - Follow:
    - `src/app/api/auth/me/route.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/db/postgres-repositories.ts`
    - `src/lib/db/provider.ts`
- `POST /api/auth/register`
  - Follow:
    - `src/app/api/auth/register/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/password.ts`
    - `src/lib/auth/rate-limit.ts`
    - `src/lib/auth/session.ts`
- `GET /api/health`
  - Follow:
    - `src/app/api/health/route.ts`
    - `src/lib/health.ts`
    - `src/lib/db/provider.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/market/provider.ts`
  - Tests:
    - `src/app/api/health/deep/route.test.ts`
    - `src/lib/health.test.ts`
- `GET /api/health/deep`
  - Follow:
    - `src/app/api/health/deep/route.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/health.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/db/provider.ts`
  - Tests:
    - `src/app/api/health/deep/route.test.ts`
    - `src/lib/health.test.ts`
- `POST /api/maintenance/cleanup`
  - Follow:
    - `src/app/api/maintenance/cleanup/route.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/maintenance/cleanup.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/db/postgres-repositories.ts`
  - Tests:
    - `src/lib/maintenance/cleanup.test.ts`
- `GET /api/market/bars/:symbol`
  - Follow:
    - `src/app/api/market/bars/[symbol]/route.ts`
    - `src/lib/market/provider.ts`
    - `src/lib/market/chart-bars.ts`
    - `src/lib/rules/types.ts`
    - `src/lib/config/env.ts`
  - Tests:
    - `src/app/api/market/bars/[symbol]/route.test.ts`
    - `src/lib/market/alpaca-market-data.test.ts`
    - `src/lib/market/chart-bars.test.ts`
    - `src/lib/market/mock-market-data.test.ts`
    - `src/lib/market/provider.test.ts`
- `GET /api/market/diagnostics`
  - Follow:
    - `src/app/api/market/diagnostics/route.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/market/diagnostics.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/db/provider.ts`
  - Tests:
    - `src/app/api/market/bars/[symbol]/route.test.ts`
    - `src/lib/market/alpaca-market-data.test.ts`
    - `src/lib/market/chart-bars.test.ts`
    - `src/lib/market/mock-market-data.test.ts`
    - `src/lib/market/provider.test.ts`
- `GET /api/market/snapshot/:symbol`
  - Follow:
    - `src/app/api/market/snapshot/[symbol]/route.ts`
    - `src/lib/market/provider.ts`
    - `src/lib/rules/types.ts`
    - `src/lib/config/env.ts`
    - `src/lib/market/alpaca-market-data.ts`
  - Tests:
    - `src/app/api/market/bars/[symbol]/route.test.ts`
    - `src/lib/market/alpaca-market-data.test.ts`
    - `src/lib/market/chart-bars.test.ts`
    - `src/lib/market/mock-market-data.test.ts`
    - `src/lib/market/provider.test.ts`
- `GET /api/market/status`
  - Follow:
    - `src/app/api/market/status/route.ts`
    - `src/lib/market/provider.ts`
    - `src/lib/config/env.ts`
    - `src/lib/market/alpaca-market-data.ts`
    - `src/lib/market/mock-market-data.ts`
  - Tests:
    - `src/app/api/market/bars/[symbol]/route.test.ts`
    - `src/lib/market/alpaca-market-data.test.ts`
    - `src/lib/market/chart-bars.test.ts`
    - `src/lib/market/mock-market-data.test.ts`
    - `src/lib/market/provider.test.ts`
- `GET /api/notifications/channels`
  - Follow:
    - `src/app/api/notifications/channels/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/db/postgres-repositories.ts`
    - `src/lib/db/provider.ts`
  - Tests:
    - `src/lib/notifications/notification-service.test.ts`

## Agent Search Guide

- Read first:
  - `package.json` - Node package manifest and scripts
  - `README.md` - Project documentation
  - `src/app/api/health/deep/route.ts` - Health endpoint implementation
  - `src/app/api/health/route.ts` - Health endpoint implementation
  - `src/app/api/auth/login/route.ts` - API route handler
  - `src/app/api/auth/logout/route.ts` - API route handler
  - `src/app/api/auth/me/route.ts` - API route handler
  - `docs/deployment-checklist.md` - Deployment documentation
- Search by directory role:
  - `db/migrations/` - Database schema migration files
  - `src/app/api/` - Next.js API route handlers
  - `src/lib/` - Shared library/application code
  - `db/` - Database schema/migrations
  - `scripts/` - Operational scripts/tooling
  - `src/` - Frontend/source application code
- Inspect dependency hubs before leaf files:
  - `src/lib/db/repositories.ts` - imports 4 internal file(s), imported by 45 internal file(s)
  - `src/lib/rules/types.ts` - imports 0 internal file(s), imported by 36 internal file(s)
  - `src/lib/auth/session.ts` - imports 1 internal file(s), imported by 32 internal file(s)
  - `src/lib/market/provider.ts` - imports 4 internal file(s), imported by 13 internal file(s)
  - `src/lib/worker/local-mock-worker.ts` - imports 10 internal file(s), imported by 6 internal file(s)

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For API behavior, start from the API Routes section and follow imports from each route file.
- For configuration questions, inspect the Environment Variables section before opening env-related files.
- For expected behavior, use the Tests section to find representative test files and scripts.

## Changes Since Previous Snapshot

- Previous snapshot: `20260625-031728`
- Current generated: `2026-06-25 11:34:00`
- Audit status: `not run` -> `not run`

- No deterministic changes were detected since the previous snapshot.

- Added routes: none
- Removed routes: none
- Added env vars: none
- Removed env vars: none
- Added findings: none
- Resolved findings: none
- Stack changes: none
- Framework changes: none
- Database changes: none
- Test signal changes: none
- Deployment signal changes: none
- Key file changes: none

## Detected Stack

- Languages: TypeScript, JavaScript
- Frameworks: Next.js, React, Node.js
- Libraries: none detected
- Databases: PostgreSQL
- Testing: Vitest
- Deployment: Vercel

## Project Structure

- `db/migrations/` — Database schema migration files. 2 files scanned.
- `src/app/api/` — Next.js API route handlers. 37 files scanned.
- `src/lib/` — Shared library/application code. 54 files scanned.
- `db/` — Database schema/migrations. 3 files scanned.
- `scripts/` — Operational scripts/tooling. 10 files scanned.
- `src/` — Frontend/source application code. 117 files scanned.
- `src/app/` — Next.js app routes/pages. 62 files scanned.
- `docs/` — Documentation. 4 files scanned.

## Key Files

- `.env.example` — Environment variable template.
- `README.md` — Project documentation.
- `next.config.ts` — Next.js config.
- `package.json` — Node package manifest and scripts.
- `src/app/api/health/deep/route.ts` — Health endpoint implementation.
- `src/app/api/health/route.ts` — Health endpoint implementation.
- `db/migrations/001_initial.sql` — Database migration.
- `db/migrations/002_symbol_levels.sql` — Database migration.
- `docs/deployment-checklist.md` — Deployment documentation.
- `docs/deployment-prep.md` — Deployment documentation.

## File Connections

- `src/lib/db/repositories.ts` — source file; Shared module imported by multiple files; imports 4 internal file(s), imported by 45 internal file(s).
- `src/lib/rules/types.ts` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 36 internal file(s).
- `src/lib/auth/session.ts` — source file; Shared module imported by multiple files; imports 1 internal file(s), imported by 32 internal file(s).
- `src/lib/market/provider.ts` — source file; Shared module imported by multiple files; imports 4 internal file(s), imported by 13 internal file(s).
- `src/lib/worker/local-mock-worker.ts` — background/worker process; Entrypoint that connects to other project modules; imports 10 internal file(s), imported by 6 internal file(s).
- `src/lib/config/env.ts` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 12 internal file(s).
- `src/lib/auth/require-user.ts` — source file; Shared module imported by multiple files; imports 1 internal file(s), imported by 9 internal file(s).
- `src/lib/rules/level-context.ts` — source file; Shared module imported by multiple files; imports 3 internal file(s), imported by 7 internal file(s).
- `src/lib/symbol-levels.ts` — source file; Shared module imported by multiple files; imports 1 internal file(s), imported by 9 internal file(s).
- `src/lib/health.ts` — source file; Shared module imported by multiple files; imports 6 internal file(s), imported by 3 internal file(s).

## Important Exports

- `src/lib/db/repositories.ts`
  - `getRepository` (function)
  - `getRepositoryProvider` (function)
  - `addWatchlistSymbol` (value)
  - `countAlertsToday` (value)
  - `countNotificationAttemptsToday` (value)
  - `countProviderErrorsSince` (value)
  - `createAlertEvent` (value)
  - `createNotificationChannel` (value)
- `src/lib/auth/session.ts`
  - `createSession` (function)
  - `deleteSession` (function)
  - `getCurrentUser` (function)
  - `SessionUser` (type)
- `src/lib/market/provider.ts`
  - `resolveMarketDataProviderMode` (function)
  - `MarketDataProviderMode` (type)
  - `activeMarketDataProvider` (value)
  - `configuredMarketDataProvider` (value)
  - `marketData` (value)
  - `marketDataProviderMode` (value)
- `src/lib/db/postgres-repositories.ts`
  - `addWatchlistSymbol` (function)
  - `countAlertsToday` (function)
  - `countNotificationAttemptsToday` (function)
  - `countProviderErrorsSince` (function)
  - `createAlertEvent` (function)
  - `createNotificationChannel` (function)
  - `createNotificationLog` (function)
  - `createProviderErrorLog` (function)
- `src/lib/rules/schema.ts`
  - `isPriceTargetCondition` (function)
  - `validateAlertRule` (function)
  - `alertRuleSchema` (value)
  - `isPriceLikeIndicator` (value)
- `src/lib/db/provider.ts`
  - `assertSqliteRepositoryProvider` (function)
  - `getDatabaseProviderDiagnostics` (function)
  - `resolveDatabaseProviderMode` (function)
  - `DatabaseProviderMode` (type)
  - `RepositoryAdapterName` (type)
- `src/app/api/worker/replay/route.ts`
  - `POST` (function)
- `src/app/api/worker/status/route.ts`
  - `GET` (function)
- `src/app/api/worker/tick/route.ts`
  - `POST` (function)
- `src/lib/worker/local-mock-worker.ts`
  - `calculateAvailablePerformance` (function)
  - `getLiveWorkerBackoffStatus` (function)
  - `resetLiveWorkerBackoff` (function)
  - `runLocalMockWorkerTick` (function)
  - `runLocalReplay` (function)
  - `runReplayDataset` (function)
  - `sendRuleNotifications` (function)
  - `WorkerReplayResult` (type)
- `src/app/api/rules/validate/route.ts`
  - `POST` (function)
- `src/lib/notifications/notification-service.ts`
  - `DiscordWebhookNotificationService` (class)
  - `MockNotificationService` (class)
  - `NotificationRouterService` (class)
  - `buildAlertNotification` (function)
  - `globalDailyNotificationLimit` (function)
  - `maskNotificationDestination` (function)
  - `realNotificationsEnabled` (function)
  - `NotificationMessage` (type)

## Architecture Hints

- API route files import shared library or database-related code.
- Worker or operational scripts connect to shared application modules.
- Database migration files are present alongside database-related scripts.
- Shared modules are imported by multiple important files.

## Recommended Next Steps

- Keep this index current by running `stackindex analyze . --no-tui` after meaningful repository changes.
