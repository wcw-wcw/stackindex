StackIndex artifacts for my-website
Source: /Users/will/Workspace/my-website/.stackindex
Included when present: analysis.json, AGENTS.md, reports/repo-index.md, reports/repo-index.full.md
