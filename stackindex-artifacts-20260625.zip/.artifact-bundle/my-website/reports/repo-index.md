# StackIndex Repo Index

Generated: 2026-06-25 11:34:00

This compact file is an agent-facing search plan. Read it before broad file searches so follow-up exploration can stay targeted. Open `repo-index.full.md` only when you need verbose routes, env vars, scripts, findings, or file counts.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `my-website`
- Path: `/Users/will/Workspace/my-website`
- Files indexed: 71
- Finding summary: 1 high, 1 medium, 5 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 6
- Large files skipped: 0
- Binary files skipped: 1
- Unresolved internal imports: 0
- Internal alias imports resolved: 0
- Confidence warnings:
  - Binary files were skipped.

## Project Context

- Likely purpose: Twitter-style social application
- Confidence: high
- README title: twt
- README summary: Small Twitter/X-inspired social app built for portfolio and demo use. Users can register, log in, create short posts, reply in threads, quote posts, repost, follow users, receive in-app notifications, and browse profiles, search results, mentions, and hashtags.
- Evidence:

  - README/package metadata points to twitter-style social application.
  - Package scripts include backend:demo:generate, backend:seed:demo, backend:seed:demo:clear, backend:test.
  - Environment variable names include CLIENT_URL, DATABASE_URL, DB_HOST, DB_NAME.
  - API routes include auth, hashtags, login, me, notifications, posts endpoints.
  - Repository structure includes api/ for serverless/api functions.

## Feature Map

### Posts

- Start here:
  - `backend/controllers/postsController.js`
  - `backend/routes/hashtags.js`
  - `backend/routes/posts.js`
  - `backend/routes/users.js`
  - `database/migrations/001_post_replies.sql`
  - `database/migrations/002_quote_posts.sql`
  - `database/migrations/003_reposts.sql`
  - `frontend/src/components/posts/Post.jsx`
- Related tests: none detected
- Search terms: `post`, `posts`, `timeline`, `repost`, `reply`
- Routes: `DELETE /posts/:id`, `DELETE /posts/:id/repost`, `GET /hashtags/:tag/posts`, `GET /posts`, `GET /posts/:id/thread`, `GET /users/:id/posts`, `POST /posts`, `POST /posts/:id/quote`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Users

- Start here:
  - `backend/controllers/usersController.js`
  - `backend/routes/users.js`
  - `database/migrations/006_demo_accounts.sql`
- Related tests: none detected
- Search terms: `user`, `users`, `account`, `profile`
- Routes: `DELETE /users/:id/follow`, `GET /users/:id`, `GET /users/:id/followers`, `GET /users/:id/following`, `GET /users/:id/posts`, `POST /users/:id/follow`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Notifications

- Start here:
  - `backend/lib/notifications.js`
  - `backend/controllers/notificationsController.js`
  - `backend/routes/notifications.js`
  - `database/migrations/005_notifications.sql`
  - `frontend/src/pages/Notifications.jsx`
- Related tests: none detected
- Search terms: `notification`, `notifications`, `email`, `webhook`
- Routes: `GET /notifications`, `GET /notifications/unread-count`, `PATCH /notifications/:id/read`, `PATCH /notifications/read-all`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Auth

- Start here:
  - `backend/middleware/auth.js`
  - `backend/routes/auth.js`
  - `frontend/src/pages/Login.jsx`
- Related tests: none detected
- Search terms: `auth`, `session`, `cookie`, `login`, `logout`
- Routes: `GET /auth/me`, `POST /auth/login`, `POST /auth/register`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Search

- Start here:
  - `backend/controllers/searchController.js`
  - `backend/routes/search.js`
  - `frontend/src/pages/Search.jsx`
- Related tests: none detected
- Search terms: `search`, `query`, `results`
- Routes: `GET /search`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Hashtags

- Start here:
  - `backend/routes/hashtags.js`
  - `frontend/src/pages/Hashtag.jsx`
- Related tests: none detected
- Search terms: `hashtag`, `hashtags`, `tag`
- Routes: `GET /hashtags/:tag/posts`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Users / profiles

- Start here:
  - `backend/scripts/demo-profiles.js`
  - `frontend/src/components/profile/ProfileUserRow.jsx`
  - `frontend/src/pages/Profile.jsx`
  - `frontend/src/pages/ProfileConnections.jsx`
- Related tests: none detected
- Search terms: `profile`, `profiles`, `users`, `bio`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Repost

- Start here:
  - `backend/routes/posts.js`
- Related tests: none detected
- Search terms: `repost`
- Routes: `DELETE /posts/:id/repost`, `POST /posts/:id/repost`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

## Task Search Recipes

### Fix API Behavior

1. Open the matching file in API Routes or Route Implementation Chains.
2. Follow the listed imports into shared `src/lib/`, database, schema, or validation files.
3. Open the nearest related test from Feature Map or Route Implementation Chains.
4. Broaden to whole-repo search only after route, schema, storage, and tests are checked.

### Fix UI Behavior

1. Start from the matching `src/app/<feature>/page.*` or sibling component in Feature Map.
2. Search inside that feature folder and matching `src/lib/<feature>/` before shared modules.
3. Check API calls and route handlers before editing shared database code.
4. Avoid global styles/assets unless the task is visual or layout-specific.

### Fix Env Or Deployment Issue

1. Open `.env.example` if present.
2. Open env/config files from Key Files or Feature Map.
3. Check deployment docs, migrations, and package scripts.
4. Avoid unrelated feature files unless they reference the specific env var.

## Route Implementation Chains

- `ANY /api`
  - Follow:
    - `api/index.js`
    - `backend/server.js`
    - `backend/routes/auth.js`
    - `backend/routes/hashtags.js`
    - `backend/routes/notifications.js`
- `POST /auth/login`
  - Follow:
    - `backend/routes/auth.js`
    - `backend/controllers/authController.js`
    - `backend/middleware/auth.js`
    - `backend/db.js`
- `GET /auth/me`
  - Follow:
    - `backend/routes/auth.js`
    - `backend/controllers/authController.js`
    - `backend/middleware/auth.js`
    - `backend/db.js`
- `POST /auth/register`
  - Follow:
    - `backend/routes/auth.js`
    - `backend/controllers/authController.js`
    - `backend/middleware/auth.js`
    - `backend/db.js`
- `GET /hashtags/:tag/posts`
  - Follow:
    - `backend/routes/hashtags.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/searchController.js`
    - `backend/lib/postRows.js`
    - `backend/db.js`
- `GET /notifications`
  - Follow:
    - `backend/routes/notifications.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/notificationsController.js`
    - `backend/lib/notifications.js`
    - `backend/db.js`
- `PATCH /notifications/:id/read`
  - Follow:
    - `backend/routes/notifications.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/notificationsController.js`
    - `backend/lib/notifications.js`
    - `backend/db.js`
- `PATCH /notifications/read-all`
  - Follow:
    - `backend/routes/notifications.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/notificationsController.js`
    - `backend/lib/notifications.js`
    - `backend/db.js`
- `GET /notifications/unread-count`
  - Follow:
    - `backend/routes/notifications.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/notificationsController.js`
    - `backend/lib/notifications.js`
    - `backend/db.js`
- `GET /posts`
  - Follow:
    - `backend/routes/posts.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/postsController.js`
    - `backend/lib/discovery.js`
    - `backend/lib/notifications.js`
- `POST /posts`
  - Follow:
    - `backend/routes/posts.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/postsController.js`
    - `backend/lib/discovery.js`
    - `backend/lib/notifications.js`
- `DELETE /posts/:id`
  - Follow:
    - `backend/routes/posts.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/postsController.js`
    - `backend/lib/discovery.js`
    - `backend/lib/notifications.js`

## Agent Search Guide

- Read first:
  - `README.md` - Project documentation
  - `frontend/README.md` - Project documentation
  - `frontend/vite.config.js` - Vite config
  - `api/index.js` - Serverless/API function
  - `backend/routes/auth.js` - API route handler
  - `backend/routes/hashtags.js` - API route handler
  - `backend/routes/notifications.js` - API route handler
  - `backend/routes/posts.js` - API route handler
- Search by directory role:
  - `api/` - Serverless/API functions
  - `backend/` - Backend service
  - `backend/routes/` - Backend API routes
  - `database/migrations/` - Database schema migration files
  - `frontend/` - Frontend app
  - `frontend/src/` - Frontend source code
- Inspect dependency hubs before leaf files:
  - `frontend/src/App.jsx` - imports 11 internal file(s), imported by 1 internal file(s)
  - `frontend/src/lib/api.js` - imports 0 internal file(s), imported by 11 internal file(s)
  - `backend/db.js` - imports 0 internal file(s), imported by 8 internal file(s)
  - `backend/server.js` - imports 6 internal file(s), imported by 1 internal file(s)
  - `frontend/src/components/posts/Post.jsx` - imports 5 internal file(s), imported by 2 internal file(s)

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For API behavior, start from the API Routes section and follow imports from each route file.
- For configuration questions, inspect the Environment Variables section before opening env-related files.
- For risk review, start with Findings; each item names the category and usually the relevant file.

## Changes Since Previous Snapshot

- Previous snapshot: `20260625-031728`
- Current generated: `2026-06-25 11:34:00`
- Audit status: `not run` -> `not run`

- No deterministic changes were detected since the previous snapshot.

- Added routes: none
- Removed routes: none
- Added env vars: none
- Removed env vars: none
- Added findings: none
- Resolved findings: none
- Stack changes: none
- Framework changes: none
- Database changes: none
- Test signal changes: none
- Deployment signal changes: none
- Key file changes: none

## Detected Stack

- Languages: JavaScript
- Frameworks: Vite, React, Express, Node.js
- Libraries: none detected
- Databases: PostgreSQL
- Testing: none detected
- Deployment: Vercel

## Project Structure

- `api/` — Serverless/API functions. 1 files scanned.
- `backend/` — Backend service. 24 files scanned.
- `backend/routes/` — Backend API routes. 6 files scanned.
- `database/migrations/` — Database schema migration files. 6 files scanned.
- `frontend/` — Frontend app. 34 files scanned.
- `frontend/src/` — Frontend source code. 26 files scanned.
- `database/` — Database schema/migrations. 7 files scanned.
- `docs/` — Documentation. 1 files scanned.

## Key Files

- `.env.example` — Environment variable template.
- `README.md` — Project documentation.
- `frontend/README.md` — Project documentation.
- `frontend/vite.config.js` — Vite config.
- `vercel.json` — Vercel deployment config.
- `api/index.js` — Serverless/API function.
- `backend/routes/auth.js` — API route handler.
- `backend/routes/hashtags.js` — API route handler.
- `backend/routes/notifications.js` — API route handler.
- `backend/routes/posts.js` — API route handler.

## File Connections

- `frontend/src/App.jsx` — source file; Coordinates several internal modules; imports 11 internal file(s), imported by 1 internal file(s).
- `frontend/src/lib/api.js` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 11 internal file(s).
- `backend/db.js` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 8 internal file(s).
- `backend/server.js` — source file; Entrypoint that connects to other project modules; imports 6 internal file(s), imported by 1 internal file(s).
- `frontend/src/components/posts/Post.jsx` — source file; Shared module imported by multiple files; imports 5 internal file(s), imported by 2 internal file(s).
- `backend/middleware/auth.js` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 6 internal file(s).
- `frontend/src/components/common/DemoBadge.jsx` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 6 internal file(s).
- `frontend/src/components/posts/Timeline.jsx` — source file; Shared module imported by multiple files; imports 1 internal file(s), imported by 5 internal file(s).
- `backend/controllers/postsController.js` — source file; Coordinates several internal modules; imports 4 internal file(s), imported by 1 internal file(s).
- `backend/lib/notifications.js` — source file; Shared module imported by multiple files; imports 1 internal file(s), imported by 4 internal file(s).

## Important Exports

- `frontend/src/lib/api.js`
  - `API_BASE_URL` (value)
  - `fetchNotifications` (value)
  - `fetchUnreadNotificationCount` (value)
  - `getAuthHeaders` (value)
  - `getToken` (value)
  - `markAllNotificationsRead` (value)
  - `markNotificationRead` (value)
  - `repostPost` (value)

## Architecture Hints

- Database migration files are present in the repository.
- Serverless/API files or local API scripts are present, but no health endpoint was detected.

## Recommended Next Steps

- **high / env**: Use safe placeholders in .env.example and keep real values only in local .env files.
- **medium / package**: Add a production start script.
- **low / tests**: Add a small smoke test or unit test suite for the critical path.
- **low / docs**: Document the basic local development flow.
- **low / deployment**: Add a simple /health or /api/health route for deployment monitoring.
- **low / deployment**: Document how to run migrations in setup/deploy flows.
- **low / deployment**: Add brief deployment notes for Vercel configuration and required env vars.
