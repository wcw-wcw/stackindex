# StackIndex Repo Index

Generated: 2026-06-25 11:34:00

This compact file is an agent-facing search plan. Read it before broad file searches so follow-up exploration can stay targeted. Open `repo-index.full.md` only when you need verbose routes, env vars, scripts, findings, or file counts.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `bladerivals`
- Path: `/Users/will/Workspace/bladerivals`
- Files indexed: 39
- Finding summary: 0 high, 0 medium, 1 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 3
- Large files skipped: 0
- Binary files skipped: 0
- Unresolved internal imports: 0
- Internal alias imports resolved: 0

## Project Context

- Likely purpose: Roblox melee arena
- Confidence: high
- README title: BladeRivals
- README summary: BladeRivals is a Rojo v7 Roblox Luau prototype for a 1v1 melee arena game. The current slice focuses on a playable test loop: lobby, queue, best-of-5 duel, first-person combat, return to lobby, and enough debug feedback to playtest quickly.
- Evidence:

  - README/package metadata points to roblox melee arena.
  - Repository structure includes src/client/ for roblox client code.

## Feature Map

### Frontend game UI

- Start here:
  - `src/client/controllers/AnimationController.luau`
  - `src/client/controllers/CameraController.luau`
  - `src/client/controllers/CombatController.luau`
  - `src/client/controllers/EffectsController.luau`
  - `src/client/controllers/FeedbackController.luau`
  - `src/client/controllers/HudController.luau`
  - `src/client/controllers/InputController.luau`
  - `src/client/controllers/MovementController.luau`
- Related tests: none detected
- Search terms: `frontend-game-ui`, `frontend`, `board`, `ui`, `game`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Backend services

- Start here:
  - `src/server/services/AbilityService.luau`
  - `src/server/services/ArenaService.luau`
  - `src/server/services/CombatService.luau`
  - `src/server/services/InventoryService.luau`
  - `src/server/services/LobbyService.luau`
  - `src/server/services/MatchService.luau`
  - `src/server/services/PersistenceService.luau`
  - `src/server/services/PlayerStateService.luau`
- Related tests: none detected
- Search terms: `backend-service`, `service`, `services`, `backend`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Weapon definitions

- Start here:
  - `src/client/controllers/ViewmodelWeaponBuilder.luau`
  - `src/server/services/ThirdPersonWeaponService.luau`
  - `src/shared/AbilityDefinitions.luau`
  - `src/shared/AnimationDefinitions.luau`
  - `src/shared/AssetDefinitions.luau`
  - `src/shared/EffectDefinitions.luau`
  - `src/shared/FeedbackDefinitions.luau`
  - `src/shared/MovementDefinitions.luau`
- Related tests: none detected
- Search terms: `weapon-definition`, `weapon`, `weapons`, `definition`, `sword`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Viewmodel

- Start here:
  - `src/client/controllers/CameraController.luau`
  - `src/client/controllers/ViewmodelController.luau`
  - `src/client/controllers/ViewmodelWeaponBuilder.luau`
- Related tests: none detected
- Search terms: `viewmodel`, `camera`, `arms`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Abilities

- Start here:
  - `src/server/services/AbilityService.luau`
  - `src/shared/AbilityDefinitions.luau`
- Related tests: none detected
- Search terms: `ability`, `abilities`, `skill`, `cooldown`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: low

### Combat

- Start here:
  - `src/client/controllers/CombatController.luau`
  - `src/server/services/CombatService.luau`
- Related tests: none detected
- Search terms: `combat`, `attack`, `damage`, `hitbox`, `parry`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: low

### Effects

- Start here:
  - `src/client/controllers/EffectsController.luau`
  - `src/shared/EffectDefinitions.luau`
- Related tests: none detected
- Search terms: `effect`, `effects`, `vfx`, `particles`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: low

### Movement

- Start here:
  - `src/client/controllers/MovementController.luau`
  - `src/shared/MovementDefinitions.luau`
- Related tests: none detected
- Search terms: `movement`, `dash`, `sprint`, `jump`, `controller`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: low

## Task Search Recipes

## Agent Search Guide

- Read first:
  - `README.md` - Project documentation
  - `default.project.json` - Rojo project config
- Search by directory role:
  - `src/client/` - Roblox client code
  - `src/client/controllers/` - Roblox client controllers
  - `src/server/` - Roblox server code
  - `src/server/services/` - Roblox server services
  - `src/shared/` - Roblox shared definitions/remotes/config
  - `src/` - Frontend/source application code

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For risk review, start with Findings; each item names the category and usually the relevant file.

## Changes Since Previous Snapshot

- Previous snapshot: `20260625-031729`
- Current generated: `2026-06-25 11:34:00`
- Audit status: `not run` -> `not run`

- No deterministic changes were detected since the previous snapshot.

- Added routes: none
- Removed routes: none
- Added env vars: none
- Removed env vars: none
- Added findings: none
- Resolved findings: none
- Stack changes: none
- Framework changes: none
- Database changes: none
- Test signal changes: none
- Deployment signal changes: none
- Key file changes: none

## Detected Stack

- Languages: Luau
- Frameworks: Rojo, Roblox
- Libraries: none detected
- Databases: none detected
- Testing: none detected
- Deployment: none detected

## Project Structure

- `src/client/` — Roblox client code. 12 files scanned.
- `src/client/controllers/` — Roblox client controllers. 11 files scanned.
- `src/server/` — Roblox server code. 11 files scanned.
- `src/server/services/` — Roblox server services. 10 files scanned.
- `src/shared/` — Roblox shared definitions/remotes/config. 10 files scanned.
- `src/` — Frontend/source application code. 33 files scanned.

## Key Files

- `README.md` — Project documentation.
- `default.project.json` — Rojo project config.

## Recommended Next Steps

- **low / tests**: Add a small smoke test or unit test suite for the critical path.
