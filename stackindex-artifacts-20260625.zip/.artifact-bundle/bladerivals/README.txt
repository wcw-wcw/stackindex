StackIndex artifacts for bladerivals
Source: /Users/will/Workspace/bladerivals/.stackindex
Included when present: analysis.json, AGENTS.md, reports/repo-index.md, reports/repo-index.full.md
