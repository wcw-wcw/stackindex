StackIndex artifacts for assessmentapp
Source: /Users/will/Workspace/assessmentapp/.stackindex
Included when present: analysis.json, AGENTS.md, reports/repo-index.md, reports/repo-index.full.md
