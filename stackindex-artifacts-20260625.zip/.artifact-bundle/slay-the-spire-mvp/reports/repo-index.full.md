# StackIndex Full Repo Index

Generated: 2026-06-25 11:34:00

This is the verbose companion to `repo-index.md`. Use it when the compact search plan is not enough.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `slay-the-spire-mvp`
- Path: `/Users/will/Workspace/slay-the-spire-mvp`
- Files indexed: 11
- Finding summary: 0 high, 0 medium, 3 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 1
- Large files skipped: 0
- Binary files skipped: 0
- Unresolved internal imports: 2
- Internal alias imports resolved: 0
- Confidence warnings:
  - Some internal imports could not be resolved; route chains may be incomplete.

## Feature Map Quality

- Feature map confidence: low
- Reason: Feature Map has fewer than 2 useful compact features; use Agent Search Guide and Key Files first.
- Start with Agent Search Guide and Key Files before broad searches.

## Small Project Guidance

- Read README, package metadata, and the main entrypoint first.
- Broad search is acceptable after checking Key Files.
- Use `repo-index.full.md` only if the compact index is not enough.

## Project Context

- Likely purpose: Slay-the-Spire-like card game
- Confidence: medium
- Evidence:

  - Package scripts include build, dev, test, test:coverage.
  - Repository structure includes src/ for frontend/source application code.

## Feature Map

### Games

- Start here:
  - `src/game/cards/definitions.ts`
  - `src/game/enemies/definitions.ts`
- Related tests: none detected
- Search terms: `game`, `games`, `match`, `moves`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: low

## Task Search Recipes

## Agent Search Guide

- Read first:
  - `package.json` - Node package manifest and scripts
  - `vite.config.ts` - Vite config
  - `tsconfig.json` - TypeScript config
- Search by directory role:
  - `src/` - Frontend/source application code
  - `src/types/` - Shared types

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For expected behavior, use the Tests section to find representative test files and scripts.
- For risk review, start with Findings; each item names the category and usually the relevant file.

## Changes Since Previous Snapshot

- Previous snapshot: `20260625-031729`
- Current generated: `2026-06-25 11:34:00`
- Audit status: `not run` -> `not run`

- No deterministic changes were detected since the previous snapshot.

- Added routes: none
- Removed routes: none
- Added env vars: none
- Removed env vars: none
- Added findings: none
- Resolved findings: none
- Stack changes: none
- Framework changes: none
- Database changes: none
- Test signal changes: none
- Deployment signal changes: none
- Key file changes: none

## Detected Stack

- Languages: JavaScript, TypeScript
- Frameworks: Tailwind CSS, Vite, React, Node.js
- Libraries: none detected
- Databases: none detected
- Testing: Vitest
- Deployment: none detected

## Project Structure

- `src/` — Frontend/source application code. 3 files scanned.
- `src/types/` — Shared types. 1 files scanned.

## Key Files

- `package.json` — Node package manifest and scripts.
- `vite.config.ts` — Vite config.
- `tsconfig.json` — TypeScript config.

## Important Exports

- `src/game/cards/definitions.ts`
  - `getCard` (function)
  - `ALL_CARDS` (value)
  - `CARD_MAP` (value)
  - `REWARD_POOL` (value)
  - `STARTER_DECK_IDS` (value)
- `src/game/enemies/definitions.ts`
  - `ALL_ENEMIES` (value)
  - `BOSS_ENEMY_ID` (value)
  - `CULTIST` (value)
  - `ELITE_ENEMY_IDS` (value)
  - `ENEMY_MAP` (value)
  - `FUNGAL_BEAST` (value)
  - `GREMLIN_NOB` (value)
  - `JAW_WORM` (value)

## File Overview

- Source files: 6
- Config files: 4
- Test files: 0
- Docs: 0

## Package Scripts

- `build`: `tsc && vite build`
- `dev`: `vite`
- `preview`: `vite preview`
- `test`: `vitest`
- `test:coverage`: `vitest run --coverage`
- `test:ui`: `vitest --ui`

## Environment Variables

No environment variable usage detected.

## API Routes

No API routes detected.

## Tests

- Test files: no
- Test script: yes
- Frameworks: Vitest

## Deployment Readiness

- README: no
- `.env.example`: no
- Dockerfile: no
- Vercel config: no
- Health endpoint: no
- Migration files: no

## Findings

- **low / package**: No lint script found. (`package.json`)
  Recommendation: Add a lint script for local and CI readiness.
- **low / tests**: No obvious test files were found.
  Recommendation: Add a small smoke test or unit test suite for the critical path.
- **low / docs**: No README.md found.
  Recommendation: Add a README with setup, run, and deployment notes.

## Recommended Next Steps

- **low / package**: Add a lint script for local and CI readiness.
- **low / tests**: Add a small smoke test or unit test suite for the critical path.
- **low / docs**: Add a README with setup, run, and deployment notes.
