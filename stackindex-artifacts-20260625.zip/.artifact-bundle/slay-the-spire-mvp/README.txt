StackIndex artifacts for slay-the-spire-mvp
Source: /Users/will/Workspace/slay-the-spire-mvp/.stackindex
Included when present: analysis.json, AGENTS.md, reports/repo-index.md, reports/repo-index.full.md
