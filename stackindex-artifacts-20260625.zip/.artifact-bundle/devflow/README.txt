StackIndex artifacts for devflow
Source: /Users/will/Workspace/devflow/.stackindex
Included when present: analysis.json, AGENTS.md, reports/repo-index.md, reports/repo-index.full.md
