# StackIndex Repo Index

Generated: 2026-06-25 11:34:00

This compact file is an agent-facing search plan. Read it before broad file searches so follow-up exploration can stay targeted. Open `repo-index.full.md` only when you need verbose routes, env vars, scripts, findings, or file counts.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `devflow`
- Path: `/Users/will/Workspace/devflow`
- Files indexed: 23
- Finding summary: 0 high, 2 medium, 1 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 5
- Large files skipped: 0
- Binary files skipped: 1
- Unresolved internal imports: 1
- Internal alias imports resolved: 0
- Confidence warnings:
  - Some internal imports could not be resolved; route chains may be incomplete.
  - Alias-looking imports were detected but could not be resolved from tsconfig/jsconfig paths or baseUrl.
  - Binary files were skipped.

## Feature Map Quality

- Feature map confidence: low
- Reason: Feature Map has fewer than 2 useful compact features; use Agent Search Guide and Key Files first.
- Start with Agent Search Guide and Key Files before broad searches.

## Small Project Guidance

- Read README, package metadata, and the main entrypoint first.
- Broad search is acceptable after checking Key Files.
- Use `repo-index.full.md` only if the compact index is not enough.

## Project Context

- Likely purpose: Local-first developer dashboard
- Confidence: high
- README title: DevFlow
- README summary: DevFlow is a local-first dashboard for software development work. It tracks local and GitHub-oriented projects, repo status, commits, notes, tasks, and source files in one focused workspace.
- Evidence:

  - README/package metadata points to local-first developer dashboard.
  - Package scripts include app:open, build, dev, dev:api.
  - Environment variable names include JWT_SECRET, PORT.
  - Repository structure includes ./ for root local node backend/server.

## Task Search Recipes

### Fix Env Or Deployment Issue

1. Open `.env.example` if present.
2. Open env/config files from Key Files or Feature Map.
3. Check deployment docs, migrations, and package scripts.
4. Avoid unrelated feature files unless they reference the specific env var.

## Agent Search Guide

- Read first:
  - `package.json` - Node package manifest and scripts
  - `src-tauri/Cargo.toml` - Tauri/Rust package manifest
  - `README.md` - Project documentation
  - `src/app.js` - Frontend application entrypoint
  - `server.js` - Local Node backend/server entrypoint
  - `src-tauri/src/lib.rs` - Tauri/Rust backend entrypoint
  - `src-tauri/src/main.rs` - Tauri/Rust backend entrypoint
  - `src-tauri/tauri.conf.json` - Tauri application config
- Search by directory role:
  - `./` - Root local Node backend/server
  - `src-tauri/` - Tauri desktop application shell
  - `src-tauri/src/` - Tauri/Rust backend code
  - `src-tauri/capabilities/` - Tauri permissions/config
  - `src/` - Frontend/source application code
- Inspect dependency hubs before leaf files:
  - `server.js` - imports 0 internal file(s), imported by 0 internal file(s)
  - `src/app.js` - imports 0 internal file(s), imported by 0 internal file(s)

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For configuration questions, inspect the Environment Variables section before opening env-related files.
- For risk review, start with Findings; each item names the category and usually the relevant file.

## Changes Since Previous Snapshot

- Previous snapshot: `20260625-030403`
- Current generated: `2026-06-25 11:34:00`
- Audit status: `not run` -> `not run`

- No deterministic changes were detected since the previous snapshot.

- Added routes: none
- Removed routes: none
- Added env vars: none
- Removed env vars: none
- Added findings: none
- Resolved findings: none
- Stack changes: none
- Framework changes: none
- Database changes: none
- Test signal changes: none
- Deployment signal changes: none
- Key file changes: none

## Detected Stack

- Languages: JavaScript, Rust
- Frameworks: Tauri, Vite, Node.js
- Libraries: none detected
- Databases: none detected
- Testing: none detected
- Deployment: none detected

## Project Structure

- `./` — Root local Node backend/server. 1 files scanned.
- `src-tauri/` — Tauri desktop application shell. 11 files scanned.
- `src-tauri/src/` — Tauri/Rust backend code. 2 files scanned.
- `src-tauri/capabilities/` — Tauri permissions/config. 1 files scanned.
- `src/` — Frontend/source application code. 4 files scanned.

## Key Files

- `README.md` — Project documentation.
- `package.json` — Node package manifest and scripts.
- `server.js` — Local Node backend/server entrypoint.
- `src-tauri/Cargo.toml` — Tauri/Rust package manifest.
- `src-tauri/src/lib.rs` — Tauri/Rust backend entrypoint.
- `src-tauri/src/main.rs` — Tauri/Rust backend entrypoint.
- `src-tauri/tauri.conf.json` — Tauri application config.
- `src/app.js` — Frontend application entrypoint.
- `vite.config.js` — Vite config.

## File Connections

- `server.js` — local Node backend/server entrypoint; Connected to the internal dependency graph; imports 0 internal file(s), imported by 0 internal file(s).
- `src/app.js` — frontend application entrypoint; Connected to the internal dependency graph; imports 0 internal file(s), imported by 0 internal file(s).

## Recommended Next Steps

- **medium / env**: Add a .env.example with variable names and safe placeholder values.
- **medium / deployment**: Add .env.example before deployment handoff.
- **low / tests**: Add a small smoke test or unit test suite for the critical path.
