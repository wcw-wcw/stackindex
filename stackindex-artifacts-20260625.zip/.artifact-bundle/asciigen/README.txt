StackIndex artifacts for asciigen
Source: /Users/will/Workspace/asciigen/.stackindex
Included when present: analysis.json, AGENTS.md, reports/repo-index.md, reports/repo-index.full.md
