# AGENTS.md

Use StackIndex before broad exploration in `asciigen`.

- Read `.stackindex/reports/repo-index.md` first.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before whole-repo search.
- Open `.stackindex/reports/repo-index.full.md` only when the compact index is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.
- If the index says it is stale, rerun `stackindex analyze <repo> --no-tui`.
