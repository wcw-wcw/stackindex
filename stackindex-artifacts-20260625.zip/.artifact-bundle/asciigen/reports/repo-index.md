# StackIndex Repo Index

Generated: 2026-06-25 11:34:01

This compact file is an agent-facing search plan. Read it before broad file searches so follow-up exploration can stay targeted. Open `repo-index.full.md` only when you need verbose routes, env vars, scripts, findings, or file counts.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `asciigen`
- Path: `/Users/will/Workspace/asciigen`
- Files indexed: 19
- Finding summary: 0 high, 0 medium, 2 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 5
- Large files skipped: 0
- Binary files skipped: 1
- Unresolved internal imports: 0
- Internal alias imports resolved: 0
- Confidence warnings:
  - Binary files were skipped.

## Feature Map Quality

- Feature map confidence: low
- Reason: Feature Map has fewer than 2 useful compact features; use Agent Search Guide and Key Files first.
- Start with Agent Search Guide and Key Files before broad searches.

## Small Project Guidance

- Read README, package metadata, and the main entrypoint first.
- Broad search is acceptable after checking Key Files.
- Use `repo-index.full.md` only if the compact index is not enough.

## Project Context

- Likely purpose: Tauri desktop app
- Confidence: medium
- README title: AsciiGen
- README summary: AsciiGen is a Tauri desktop app that turns images into ASCII art.
- Evidence:

  - README/package metadata points to tauri desktop app.
  - Package scripts include build, dev, tauri, tauri:build.
  - Repository structure includes src-tauri/ for tauri desktop application shell.

## Task Search Recipes

## Agent Search Guide

- Read first:
  - `package.json` - Node package manifest and scripts
  - `src-tauri/Cargo.toml` - Tauri/Rust package manifest
  - `README.md` - Project documentation
  - `src/main.ts` - Frontend application entrypoint
  - `src-tauri/src/lib.rs` - Tauri/Rust backend entrypoint
  - `src-tauri/src/main.rs` - Tauri/Rust backend entrypoint
  - `src-tauri/tauri.conf.json` - Tauri application config
  - `vite.config.ts` - Vite config
- Search by directory role:
  - `src-tauri/` - Tauri desktop application shell
  - `src-tauri/src/` - Tauri/Rust backend code
  - `src/` - Frontend/source application code
- Inspect dependency hubs before leaf files:
  - `src/main.ts` - imports 0 internal file(s), imported by 0 internal file(s)

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For risk review, start with Findings; each item names the category and usually the relevant file.

## Changes Since Previous Snapshot

- Previous snapshot: `20260625-030405`
- Current generated: `2026-06-25 11:34:01`
- Audit status: `not run` -> `not run`

- No deterministic changes were detected since the previous snapshot.

- Added routes: none
- Removed routes: none
- Added env vars: none
- Removed env vars: none
- Added findings: none
- Resolved findings: none
- Stack changes: none
- Framework changes: none
- Database changes: none
- Test signal changes: none
- Deployment signal changes: none
- Key file changes: none

## Detected Stack

- Languages: Rust, TypeScript
- Frameworks: Tauri, Vite, Node.js
- Libraries: none detected
- Databases: none detected
- Testing: none detected
- Deployment: none detected

## Project Structure

- `src-tauri/` — Tauri desktop application shell. 10 files scanned.
- `src-tauri/src/` — Tauri/Rust backend code. 2 files scanned.
- `src/` — Frontend/source application code. 2 files scanned.

## Key Files

- `README.md` — Project documentation.
- `package.json` — Node package manifest and scripts.
- `src-tauri/Cargo.toml` — Tauri/Rust package manifest.
- `src-tauri/src/lib.rs` — Tauri/Rust backend entrypoint.
- `src-tauri/src/main.rs` — Tauri/Rust backend entrypoint.
- `src-tauri/tauri.conf.json` — Tauri application config.
- `src/main.ts` — Frontend application entrypoint.
- `vite.config.ts` — Vite config.
- `tsconfig.json` — TypeScript config.

## File Connections

- `src/main.ts` — frontend application entrypoint; Connected to the internal dependency graph; imports 0 internal file(s), imported by 0 internal file(s).

## Architecture Hints

- This project appears mostly frontend/static based on Vite-style entrypoints and no detected API routes.

## Recommended Next Steps

- **low / package**: Add a lint script for local and CI readiness.
- **low / tests**: Add a small smoke test or unit test suite for the critical path.
