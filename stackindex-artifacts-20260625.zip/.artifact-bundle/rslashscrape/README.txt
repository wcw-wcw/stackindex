StackIndex artifacts for rslashscrape
Source: /Users/will/Workspace/rslashscrape/.stackindex
Included when present: analysis.json, AGENTS.md, reports/repo-index.md, reports/repo-index.full.md
