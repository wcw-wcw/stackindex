# StackIndex Full Repo Index

Generated: 2026-06-25 11:34:01

This is the verbose companion to `repo-index.md`. Use it when the compact search plan is not enough.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `rslashscrape`
- Path: `/Users/will/Workspace/rslashscrape`
- Files indexed: 7
- Finding summary: 0 high, 2 medium, 1 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 2
- Large files skipped: 0
- Binary files skipped: 0
- Unresolved internal imports: 0
- Internal alias imports resolved: 0

## Feature Map Quality

- Feature map confidence: low
- Reason: Feature Map has fewer than 2 useful compact features; use Agent Search Guide and Key Files first.
- Start with Agent Search Guide and Key Files before broad searches.

## Small Project Guidance

- Read README, package metadata, and the main entrypoint first.
- Broad search is acceptable after checking Key Files.
- Use `repo-index.full.md` only if the compact index is not enough.

## Project Context

- Likely purpose: Reddit/subreddit scraper
- Confidence: high
- README title: rslashscrape
- README summary: A small local app for scraping a user-provided subreddit and surfacing posts that are performing well.
- Evidence:

  - README/package metadata points to reddit/subreddit scraper.
  - Package scripts include dev, start.
  - Environment variable names include HOST, PORT, REDDIT_CLIENT_ID, REDDIT_CLIENT_SECRET.
  - Repository structure includes ./ for root local node backend/server.

## Task Search Recipes

### Fix Env Or Deployment Issue

1. Open `.env.example` if present.
2. Open env/config files from Key Files or Feature Map.
3. Check deployment docs, migrations, and package scripts.
4. Avoid unrelated feature files unless they reference the specific env var.

## Agent Search Guide

- Read first:
  - `package.json` - Node package manifest and scripts
  - `README.md` - Project documentation
  - `server.js` - Local Node backend/server entrypoint
- Search by directory role:
  - `./` - Root local Node backend/server
  - `public/` - Static assets
- Inspect dependency hubs before leaf files:
  - `server.js` - imports 0 internal file(s), imported by 0 internal file(s)

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For configuration questions, inspect the Environment Variables section before opening env-related files.
- For risk review, start with Findings; each item names the category and usually the relevant file.

## Changes Since Previous Snapshot

- Previous snapshot: `20260625-031729`
- Current generated: `2026-06-25 11:34:01`
- Audit status: `not run` -> `not run`

- No deterministic changes were detected since the previous snapshot.

- Added routes: none
- Removed routes: none
- Added env vars: none
- Removed env vars: none
- Added findings: none
- Resolved findings: none
- Stack changes: none
- Framework changes: none
- Database changes: none
- Test signal changes: none
- Deployment signal changes: none
- Key file changes: none

## Detected Stack

- Languages: JavaScript
- Frameworks: none detected
- Libraries: none detected
- Databases: none detected
- Testing: none detected
- Deployment: none detected

## Project Structure

- `./` — Root local Node backend/server. 1 files scanned.
- `public/` — Static assets. 3 files scanned.

## Key Files

- `README.md` — Project documentation.
- `package.json` — Node package manifest and scripts.
- `server.js` — Local Node backend/server entrypoint.

## File Connections

- `server.js` — local Node backend/server entrypoint; Connected to the internal dependency graph; imports 0 internal file(s), imported by 0 internal file(s).

## File Overview

- Source files: 2
- Config files: 2
- Test files: 0
- Docs: 1

## Package Scripts

- `dev`: `node server.js`
- `start`: `node server.js`

## Environment Variables

- `.env.example`: no

- Required app config: `HOST` (missing from `.env.example`), `REDDIT_CLIENT_SECRET` (missing from `.env.example`)
- Optional app config: `REDDIT_CLIENT_ID` (missing from `.env.example`)
- Platform/build metadata: `PORT` (detected but likely platform/build provided)
- Script-only vars: none detected
- Missing required from .env.example: `HOST`, `REDDIT_CLIENT_SECRET`

## API Routes

No API routes detected.

## Tests

- Test files: no
- Test script: no
- Frameworks: none detected

## Deployment Readiness

- README: yes
- `.env.example`: no
- Dockerfile: no
- Vercel config: no
- Health endpoint: no
- Migration files: no

## Findings

- **medium / env**: Environment variables are used, but no .env.example file was found.
  Recommendation: Add a .env.example with variable names and safe placeholder values.
- **low / tests**: No obvious test files were found.
  Recommendation: Add a small smoke test or unit test suite for the critical path.
- **medium / deployment**: Environment variables are used but not documented in .env.example.
  Recommendation: Add .env.example before deployment handoff.

## Recommended Next Steps

- **medium / env**: Add a .env.example with variable names and safe placeholder values.
- **medium / deployment**: Add .env.example before deployment handoff.
- **low / tests**: Add a small smoke test or unit test suite for the critical path.
