StackIndex artifacts for stackindex
Source: /Users/will/Workspace/stackindex/.stackindex
Included when present: analysis.json, AGENTS.md, reports/repo-index.md, reports/repo-index.full.md
