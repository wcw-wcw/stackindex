StackIndex artifacts for stackmap
Source: /Users/will/Workspace/stackmap/.stackindex
Included when present: analysis.json, AGENTS.md, reports/repo-index.md, reports/repo-index.full.md
