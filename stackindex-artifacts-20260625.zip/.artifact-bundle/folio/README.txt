StackIndex artifacts for folio
Source: /Users/will/Workspace/folio/.stackindex
Included when present: analysis.json, AGENTS.md, reports/repo-index.md, reports/repo-index.full.md
