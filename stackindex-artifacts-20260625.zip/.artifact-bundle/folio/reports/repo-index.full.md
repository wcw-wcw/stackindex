# StackIndex Full Repo Index

Generated: 2026-06-25 11:34:00

This is the verbose companion to `repo-index.md`. Use it when the compact search plan is not enough.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `folio`
- Path: `/Users/will/Workspace/folio`
- Files indexed: 29
- Finding summary: 0 high, 0 medium, 1 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 5
- Large files skipped: 2
- Binary files skipped: 5
- Unresolved internal imports: 0
- Internal alias imports resolved: 25
- Confidence warnings:
  - Large files were skipped to keep the index compact.
  - Binary files were skipped.

## Feature Map Quality

- Feature map confidence: low
- Reason: Feature Map has fewer than 2 useful compact features; use Agent Search Guide and Key Files first.
- Start with Agent Search Guide and Key Files before broad searches.

## Small Project Guidance

- Read README, package metadata, and the main entrypoint first.
- Broad search is acceptable after checking Key Files.
- Use `repo-index.full.md` only if the compact index is not enough.

## Project Context

- Likely purpose: Portfolio/personal site
- Confidence: high
- README title: Will West Portfolio
- README summary: A polished personal portfolio for Will West built with Next.js, TypeScript, Tailwind CSS, and Vercel-ready defaults. The site is a static, recruiter-friendly portfolio that presents featured projects, case studies, resume information, skills, and contact links.
- Evidence:

  - README/package metadata points to portfolio/personal site.
  - Package scripts include build, dev.
  - Repository structure includes docs/ for documentation.

## Feature Map

### Users / profiles

- Start here:
  - `data/profile.ts`
- Related tests: none detected
- Search terms: `profile`, `profiles`, `users`, `bio`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: low

## Task Search Recipes

### Fix UI Behavior

1. Start from the matching `src/app/<feature>/page.*` or sibling component in Feature Map.
2. Search inside that feature folder and matching `src/lib/<feature>/` before shared modules.
3. Check API calls and route handlers before editing shared database code.
4. Avoid global styles/assets unless the task is visual or layout-specific.

## Agent Search Guide

- Read first:
  - `package.json` - Node package manifest and scripts
  - `README.md` - Project documentation
  - `vercel.json` - Vercel deployment config
  - `next.config.ts` - Next.js config
  - `tsconfig.json` - TypeScript config
- Search by directory role:
  - `docs/` - Documentation
- Inspect dependency hubs before leaf files:
  - `app/page.tsx` - imports 7 internal file(s), imported by 0 internal file(s)
  - `components/container.tsx` - imports 0 internal file(s), imported by 7 internal file(s)
  - `app/projects/page.tsx` - imports 4 internal file(s), imported by 0 internal file(s)
  - `app/resume/page.tsx` - imports 4 internal file(s), imported by 0 internal file(s)
  - `components/button-link.tsx` - imports 0 internal file(s), imported by 4 internal file(s)

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For risk review, start with Findings; each item names the category and usually the relevant file.

## Changes Since Previous Snapshot

- Previous snapshot: `20260625-031729`
- Current generated: `2026-06-25 11:34:00`
- Audit status: `not run` -> `not run`

- No deterministic changes were detected since the previous snapshot.

- Added routes: none
- Removed routes: none
- Added env vars: none
- Removed env vars: none
- Added findings: none
- Resolved findings: none
- Stack changes: none
- Framework changes: none
- Database changes: none
- Test signal changes: none
- Deployment signal changes: none
- Key file changes: none

## Detected Stack

- Languages: TypeScript, JavaScript
- Frameworks: Next.js, Tailwind CSS, React, Node.js
- Libraries: none detected
- Databases: none detected
- Testing: none detected
- Deployment: Vercel

## Project Structure

- `docs/` — Documentation. 1 files scanned.

## Key Files

- `README.md` — Project documentation.
- `next.config.ts` — Next.js config.
- `package.json` — Node package manifest and scripts.
- `vercel.json` — Vercel deployment config.
- `tsconfig.json` — TypeScript config.

## File Connections

- `app/page.tsx` — source file; Coordinates several internal modules; imports 7 internal file(s), imported by 0 internal file(s).
- `components/container.tsx` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 7 internal file(s).
- `app/projects/page.tsx` — source file; Coordinates several internal modules; imports 4 internal file(s), imported by 0 internal file(s).
- `app/resume/page.tsx` — source file; Coordinates several internal modules; imports 4 internal file(s), imported by 0 internal file(s).
- `components/button-link.tsx` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 4 internal file(s).
- `data/profile.ts` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 4 internal file(s).
- `data/projects.ts` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 4 internal file(s).
- `components/project-card.tsx` — source file; Shared module imported by multiple files; imports 1 internal file(s), imported by 2 internal file(s).
- `components/section-heading.tsx` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 3 internal file(s).
- `app/projects/[slug]/page.tsx` — source file; Coordinates several internal modules; imports 3 internal file(s), imported by 0 internal file(s).

## Important Exports

- `data/profile.ts`
  - `education` (value)
  - `experience` (value)
  - `profile` (value)
  - `resumeHighlights` (value)
  - `skillTickerItems` (value)
  - `skills` (value)
  - `strengths` (value)
- `app/projects/[slug]/page.tsx`
  - `generateMetadata` (function)
  - `generateStaticParams` (function)
- `app/projects/page.tsx`
  - `metadata` (value)
- `app/resume/page.tsx`
  - `metadata` (value)
- `components/button-link.tsx`
  - `ButtonLink` (function)
- `components/container.tsx`
  - `Container` (function)
- `components/project-card.tsx`
  - `ProjectCard` (function)
- `components/section-heading.tsx`
  - `SectionHeading` (function)
- `data/projects.ts`
  - `getProjectBySlug` (function)
  - `Project` (type)
  - `projects` (value)

## File Overview

- Source files: 19
- Config files: 6
- Test files: 0
- Docs: 2

## Package Scripts

- `build`: `next build`
- `dev`: `next dev`
- `lint`: `next lint`
- `start`: `next start`
- `typecheck`: `tsc --noEmit`

## Environment Variables

No environment variable usage detected.

## API Routes

No API routes detected.

## Tests

- Test files: no
- Test script: no
- Frameworks: none detected

## Deployment Readiness

- README: yes
- `.env.example`: no
- Dockerfile: no
- Vercel config: yes
- Health endpoint: no
- Migration files: no

## Findings

- **low / tests**: No obvious test files were found.
  Recommendation: Add a small smoke test or unit test suite for the critical path.

## Recommended Next Steps

- **low / tests**: Add a small smoke test or unit test suite for the critical path.
