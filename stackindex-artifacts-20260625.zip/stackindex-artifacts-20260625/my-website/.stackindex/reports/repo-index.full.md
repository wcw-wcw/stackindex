# StackIndex Full Repo Index

Generated: 2026-06-25 02:53:21

This is the verbose companion to `repo-index.md`. Use it when the compact search plan is not enough.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `my-website`
- Path: `/Users/will/Workspace/my-website`
- Files indexed: 71
- Finding summary: 1 high, 2 medium, 6 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 5
- Large files skipped: 0
- Binary files skipped: 1
- Unresolved internal imports: 0
- Internal alias imports resolved: 0
- Confidence warnings:
  - Binary files were skipped.

## Project Context

- Likely purpose: Twitter-style social application
- Confidence: high
- README title: twt
- README summary: Small Twitter/X-inspired social app built for portfolio and demo use. Users can register, log in, create short posts, reply in threads, quote posts, repost, follow users, receive in-app notifications, and browse profiles, search results, mentions, and hashtags.
- Evidence:

  - README/package metadata points to twitter-style social application.
  - Package scripts include backend:demo:generate, backend:seed:demo, backend:seed:demo:clear, backend:test.
  - Environment variable names include CLIENT_URL, DATABASE_URL, DB_HOST, DB_NAME.
  - API routes include all, count, follow, followers, following, id endpoints.
  - Repository structure includes api/ for serverless/api functions.

## Feature Map

### Follow

- Start here:
  - `backend/routes/users.js`
- Related tests: none detected
- Search terms: `follow`
- Routes: `DELETE /:id/follow`, `POST /:id/follow`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Post

- Start here:
  - `backend/routes/hashtags.js`
  - `backend/routes/users.js`
- Related tests: none detected
- Search terms: `post`
- Routes: `GET /:id/posts`, `GET /:tag/posts`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Read

- Start here:
  - `backend/routes/notifications.js`
- Related tests: none detected
- Search terms: `read`
- Routes: `PATCH /:id/read`, `PATCH /read-all`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Repost

- Start here:
  - `backend/routes/posts.js`
- Related tests: none detected
- Search terms: `repost`
- Routes: `DELETE /:id/repost`, `POST /:id/repost`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### All

- Start here:
  - `backend/routes/notifications.js`
- Related tests: none detected
- Search terms: `all`
- Routes: `PATCH /read-all`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Count

- Start here:
  - `backend/routes/notifications.js`
- Related tests: none detected
- Search terms: `count`
- Routes: `GET /unread-count`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Follower

- Start here:
  - `backend/routes/users.js`
- Related tests: none detected
- Search terms: `follower`
- Routes: `GET /:id/followers`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Following

- Start here:
  - `backend/routes/users.js`
- Related tests: none detected
- Search terms: `following`
- Routes: `GET /:id/following`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Login

- Start here:
  - `backend/routes/auth.js`
- Related tests: none detected
- Search terms: `login`
- Routes: `POST /login`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Quote

- Start here:
  - `backend/routes/posts.js`
- Related tests: none detected
- Search terms: `quote`
- Routes: `POST /:id/quote`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Register

- Start here:
  - `backend/routes/auth.js`
- Related tests: none detected
- Search terms: `register`
- Routes: `POST /register`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Reply

- Start here:
  - `backend/routes/posts.js`
- Related tests: none detected
- Search terms: `reply`
- Routes: `POST /:id/replies`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Tag

- Start here:
  - `backend/routes/hashtags.js`
- Related tests: none detected
- Search terms: `tag`
- Routes: `GET /:tag/posts`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Thread

- Start here:
  - `backend/routes/posts.js`
- Related tests: none detected
- Search terms: `thread`
- Routes: `GET /:id/thread`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Unread

- Start here:
  - `backend/routes/notifications.js`
- Related tests: none detected
- Search terms: `unread`
- Routes: `GET /unread-count`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

## Task Search Recipes

### Fix API Behavior

1. Open the matching file in API Routes or Route Implementation Chains.
2. Follow the listed imports into shared `src/lib/`, database, schema, or validation files.
3. Open the nearest related test from Feature Map or Route Implementation Chains.
4. Broaden to whole-repo search only after route, schema, storage, and tests are checked.

### Fix UI Behavior

1. Start from the matching `src/app/<feature>/page.*` or sibling component in Feature Map.
2. Search inside that feature folder and matching `src/lib/<feature>/` before shared modules.
3. Check API calls and route handlers before editing shared database code.
4. Avoid global styles/assets unless the task is visual or layout-specific.

### Fix Env Or Deployment Issue

1. Open `.env.example` if present.
2. Open env/config files from Key Files or Feature Map.
3. Check deployment docs, migrations, and package scripts.
4. Avoid unrelated feature files unless they reference the specific env var.

## Route Implementation Chains

- `GET /`
  - Follow:
    - `backend/routes/posts.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/postsController.js`
    - `backend/lib/discovery.js`
    - `backend/lib/notifications.js`
- `GET /`
  - Follow:
    - `backend/routes/notifications.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/notificationsController.js`
    - `backend/lib/notifications.js`
    - `backend/db.js`
- `GET /`
  - Follow:
    - `backend/routes/search.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/searchController.js`
    - `backend/lib/postRows.js`
    - `backend/db.js`
- `POST /`
  - Follow:
    - `backend/routes/posts.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/postsController.js`
    - `backend/lib/discovery.js`
    - `backend/lib/notifications.js`
- `DELETE /:id`
  - Follow:
    - `backend/routes/posts.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/postsController.js`
    - `backend/lib/discovery.js`
    - `backend/lib/notifications.js`
- `GET /:id`
  - Follow:
    - `backend/routes/users.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/usersController.js`
    - `backend/lib/notifications.js`
    - `backend/lib/postRows.js`
- `DELETE /:id/follow`
  - Follow:
    - `backend/routes/users.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/usersController.js`
    - `backend/lib/notifications.js`
    - `backend/lib/postRows.js`
- `POST /:id/follow`
  - Follow:
    - `backend/routes/users.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/usersController.js`
    - `backend/lib/notifications.js`
    - `backend/lib/postRows.js`
- `GET /:id/followers`
  - Follow:
    - `backend/routes/users.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/usersController.js`
    - `backend/lib/notifications.js`
    - `backend/lib/postRows.js`
- `GET /:id/following`
  - Follow:
    - `backend/routes/users.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/usersController.js`
    - `backend/lib/notifications.js`
    - `backend/lib/postRows.js`
- `GET /:id/posts`
  - Follow:
    - `backend/routes/users.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/usersController.js`
    - `backend/lib/notifications.js`
    - `backend/lib/postRows.js`
- `POST /:id/quote`
  - Follow:
    - `backend/routes/posts.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/postsController.js`
    - `backend/lib/discovery.js`
    - `backend/lib/notifications.js`
- `PATCH /:id/read`
  - Follow:
    - `backend/routes/notifications.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/notificationsController.js`
    - `backend/lib/notifications.js`
    - `backend/db.js`
- `POST /:id/replies`
  - Follow:
    - `backend/routes/posts.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/postsController.js`
    - `backend/lib/discovery.js`
    - `backend/lib/notifications.js`
- `DELETE /:id/repost`
  - Follow:
    - `backend/routes/posts.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/postsController.js`
    - `backend/lib/discovery.js`
    - `backend/lib/notifications.js`
- `POST /:id/repost`
  - Follow:
    - `backend/routes/posts.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/postsController.js`
    - `backend/lib/discovery.js`
    - `backend/lib/notifications.js`
- `GET /:id/thread`
  - Follow:
    - `backend/routes/posts.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/postsController.js`
    - `backend/lib/discovery.js`
    - `backend/lib/notifications.js`
- `GET /:tag/posts`
  - Follow:
    - `backend/routes/hashtags.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/searchController.js`
    - `backend/lib/postRows.js`
    - `backend/db.js`
- `ANY /api`
  - Follow:
    - `api/index.js`
    - `backend/server.js`
    - `backend/routes/auth.js`
    - `backend/routes/hashtags.js`
    - `backend/routes/notifications.js`
- `POST /login`
  - Follow:
    - `backend/routes/auth.js`
    - `backend/controllers/authController.js`
    - `backend/middleware/auth.js`
    - `backend/db.js`
- `GET /me`
  - Follow:
    - `backend/routes/auth.js`
    - `backend/controllers/authController.js`
    - `backend/middleware/auth.js`
    - `backend/db.js`
- `PATCH /read-all`
  - Follow:
    - `backend/routes/notifications.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/notificationsController.js`
    - `backend/lib/notifications.js`
    - `backend/db.js`
- `POST /register`
  - Follow:
    - `backend/routes/auth.js`
    - `backend/controllers/authController.js`
    - `backend/middleware/auth.js`
    - `backend/db.js`
- `GET /unread-count`
  - Follow:
    - `backend/routes/notifications.js`
    - `backend/middleware/auth.js`
    - `backend/controllers/notificationsController.js`
    - `backend/lib/notifications.js`
    - `backend/db.js`

## Agent Search Guide

- Read first:
  - `README.md` - Project documentation
  - `frontend/README.md` - Project documentation
  - `frontend/vite.config.js` - Vite config
  - `api/index.js` - Serverless/API function
  - `backend/routes/auth.js` - API route handler
  - `backend/routes/hashtags.js` - API route handler
  - `backend/routes/notifications.js` - API route handler
  - `backend/routes/posts.js` - API route handler
- Search by directory role:
  - `api/` - Serverless/API functions
  - `backend/` - Backend service
  - `backend/routes/` - Backend API routes
  - `database/migrations/` - Database schema migration files
  - `frontend/` - Frontend app
  - `frontend/src/` - Frontend source code
- Inspect dependency hubs before leaf files:
  - `frontend/src/App.jsx` - imports 11 internal file(s), imported by 1 internal file(s)
  - `frontend/src/lib/api.js` - imports 0 internal file(s), imported by 11 internal file(s)
  - `backend/db.js` - imports 0 internal file(s), imported by 8 internal file(s)
  - `backend/server.js` - imports 6 internal file(s), imported by 1 internal file(s)
  - `frontend/src/components/posts/Post.jsx` - imports 5 internal file(s), imported by 2 internal file(s)

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For API behavior, start from the API Routes section and follow imports from each route file.
- For configuration questions, inspect the Environment Variables section before opening env-related files.
- For risk review, start with Findings; each item names the category and usually the relevant file.

## Changes Since Previous Snapshot

No previous snapshot yet. Run StackIndex again after another analysis to see changes.

## Detected Stack

- Languages: JavaScript
- Frameworks: Vite, React, Express, Node.js
- Libraries: none detected
- Databases: PostgreSQL
- Testing: none detected
- Deployment: Vercel

## Project Structure

- `api/` — Serverless/API functions. 1 files scanned.
- `backend/` — Backend service. 24 files scanned.
- `backend/routes/` — Backend API routes. 6 files scanned.
- `database/migrations/` — Database schema migration files. 6 files scanned.
- `frontend/` — Frontend app. 34 files scanned.
- `frontend/src/` — Frontend source code. 26 files scanned.
- `database/` — Database schema/migrations. 7 files scanned.
- `docs/` — Documentation. 1 files scanned.

## Key Files

- `.env.example` — Environment variable template.
- `README.md` — Project documentation.
- `frontend/README.md` — Project documentation.
- `frontend/vite.config.js` — Vite config.
- `vercel.json` — Vercel deployment config.
- `api/index.js` — Serverless/API function.
- `backend/routes/auth.js` — API route handler.
- `backend/routes/hashtags.js` — API route handler.
- `backend/routes/notifications.js` — API route handler.
- `backend/routes/posts.js` — API route handler.

## File Connections

- `frontend/src/App.jsx` — source file; Coordinates several internal modules; imports 11 internal file(s), imported by 1 internal file(s).
- `frontend/src/lib/api.js` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 11 internal file(s).
- `backend/db.js` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 8 internal file(s).
- `backend/server.js` — source file; Entrypoint that connects to other project modules; imports 6 internal file(s), imported by 1 internal file(s).
- `frontend/src/components/posts/Post.jsx` — source file; Shared module imported by multiple files; imports 5 internal file(s), imported by 2 internal file(s).
- `backend/middleware/auth.js` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 6 internal file(s).
- `frontend/src/components/common/DemoBadge.jsx` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 6 internal file(s).
- `frontend/src/components/posts/Timeline.jsx` — source file; Shared module imported by multiple files; imports 1 internal file(s), imported by 5 internal file(s).
- `backend/controllers/postsController.js` — source file; Coordinates several internal modules; imports 4 internal file(s), imported by 1 internal file(s).
- `backend/lib/notifications.js` — source file; Shared module imported by multiple files; imports 1 internal file(s), imported by 4 internal file(s).

## Important Exports

- `frontend/src/lib/api.js`
  - `API_BASE_URL` (value)
  - `fetchNotifications` (value)
  - `fetchUnreadNotificationCount` (value)
  - `getAuthHeaders` (value)
  - `getToken` (value)
  - `markAllNotificationsRead` (value)
  - `markNotificationRead` (value)
  - `repostPost` (value)

## Architecture Hints

- Database migration files are present in the repository.
- Serverless/API files or local API scripts are present, but no health endpoint was detected.

## File Overview

- Source files: 47
- Config files: 16
- Test files: 0
- Docs: 3

## Package Scripts

- `backend:demo:generate`: `node scripts/generate-demo-content-ollama.js`
- `backend:seed:demo`: `node scripts/seed-demo-community.js`
- `backend:seed:demo:clear`: `node scripts/clear-demo-community.js`
- `backend:test`: `echo "Error: no test specified" && exit 1`
- `frontend:build`: `vite build`
- `frontend:dev`: `vite`
- `frontend:lint`: `eslint .`
- `frontend:preview`: `vite preview`

## Environment Variables

- `.env.example`: yes

- Required app config: `CLIENT_URL`, `DATABASE_URL`, `DB_HOST`, `DB_NAME`, `DB_PASSWORD`, `DB_PORT`, `DB_USER`, `JWT_SECRET`, `VITE_API_BASE_URL`
- Optional app config: `DEV` (missing from `.env.example`), `PGSSLMODE` (missing from `.env.example`)
- Platform/build metadata: `NODE_ENV` (detected but likely platform/build provided), `PORT` (detected but likely platform/build provided)
- Script-only vars: `OLLAMA_BASE_URL` (missing from `.env.example`), `OLLAMA_MODEL` (missing from `.env.example`)
- Missing required from .env.example: none

## API Routes

- `GET /` in `backend/routes/posts.js` (medium confidence)
- `GET /` in `backend/routes/notifications.js` (medium confidence)
- `GET /` in `backend/routes/search.js` (medium confidence)
- `POST /` in `backend/routes/posts.js` (medium confidence)
- `DELETE /:id` in `backend/routes/posts.js` (medium confidence)
- `GET /:id` in `backend/routes/users.js` (medium confidence)
- `DELETE /:id/follow` in `backend/routes/users.js` (medium confidence)
- `POST /:id/follow` in `backend/routes/users.js` (medium confidence)
- `GET /:id/followers` in `backend/routes/users.js` (medium confidence)
- `GET /:id/following` in `backend/routes/users.js` (medium confidence)
- `GET /:id/posts` in `backend/routes/users.js` (medium confidence)
- `POST /:id/quote` in `backend/routes/posts.js` (medium confidence)
- `PATCH /:id/read` in `backend/routes/notifications.js` (medium confidence)
- `POST /:id/replies` in `backend/routes/posts.js` (medium confidence)
- `DELETE /:id/repost` in `backend/routes/posts.js` (medium confidence)
- `POST /:id/repost` in `backend/routes/posts.js` (medium confidence)
- `GET /:id/thread` in `backend/routes/posts.js` (medium confidence)
- `GET /:tag/posts` in `backend/routes/hashtags.js` (medium confidence)
- `ANY /api` in `api/index.js` (medium confidence; Vercel-style serverless function file.)
- `POST /login` in `backend/routes/auth.js` (medium confidence)
- `GET /me` in `backend/routes/auth.js` (medium confidence)
- `PATCH /read-all` in `backend/routes/notifications.js` (medium confidence)
- `POST /register` in `backend/routes/auth.js` (medium confidence)
- `GET /unread-count` in `backend/routes/notifications.js` (medium confidence)

## Tests

- Test files: no
- Test script: no
- Frameworks: none detected

## Deployment Readiness

- README: yes
- `.env.example`: yes
- Dockerfile: no
- Vercel config: yes
- Health endpoint: no
- Migration files: yes

## Findings

- **medium / package**: No build script found. (`package.json`)
  Recommendation: Add a build script if this project needs a production bundle.
- **low / package**: No lint script found. (`package.json`)
  Recommendation: Add a lint script for local and CI readiness.
- **medium / package**: Backend dependencies detected, but no start script was found. (`package.json`)
  Recommendation: Add a production start script.
- **high / env**: A secret-looking variable in .env.example appears to have a concrete value. (`backend/.env.example`)
  Recommendation: Use safe placeholders in .env.example and keep real values only in local .env files.
- **low / tests**: No obvious test files were found.
  Recommendation: Add a small smoke test or unit test suite for the critical path.
- **low / docs**: README does not appear to mention setup, install, or run instructions. (`README.md`)
  Recommendation: Document the basic local development flow.
- **low / deployment**: Backend/API app detected, but no health endpoint was found.
  Recommendation: Add a simple /health or /api/health route for deployment monitoring.
- **low / deployment**: Migration files exist, but README does not mention migration instructions. (`README.md`)
  Recommendation: Document how to run migrations in setup/deploy flows.
- **low / deployment**: Vercel deployment is likely, but deployment notes were not found in README. (`README.md`)
  Recommendation: Add brief deployment notes for Vercel configuration and required env vars.

## Recommended Next Steps

- **high / env**: Use safe placeholders in .env.example and keep real values only in local .env files.
- **medium / package**: Add a build script if this project needs a production bundle.
- **medium / package**: Add a production start script.
- **low / package**: Add a lint script for local and CI readiness.
- **low / tests**: Add a small smoke test or unit test suite for the critical path.
- **low / docs**: Document the basic local development flow.
- **low / deployment**: Add a simple /health or /api/health route for deployment monitoring.
- **low / deployment**: Document how to run migrations in setup/deploy flows.
- **low / deployment**: Add brief deployment notes for Vercel configuration and required env vars.
