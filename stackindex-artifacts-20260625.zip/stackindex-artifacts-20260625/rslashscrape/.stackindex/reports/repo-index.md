# StackIndex Repo Index

Generated: 2026-06-25 03:04:05

This compact file is an agent-facing search plan. Read it before broad file searches so follow-up exploration can stay targeted. Open `repo-index.full.md` only when you need verbose routes, env vars, scripts, findings, or file counts.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `rslashscrape`
- Path: `/Users/will/Workspace/rslashscrape`
- Files indexed: 7
- Finding summary: 0 high, 2 medium, 1 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 2
- Large files skipped: 0
- Binary files skipped: 0
- Unresolved internal imports: 0
- Internal alias imports resolved: 0

## Feature Map Quality

- Feature map confidence: low
- Reason: Feature Map has fewer than 2 useful compact features; use Agent Search Guide and Key Files first.
- Start with Agent Search Guide and Key Files before broad searches.

## Project Context

- Likely purpose: Twitter-style social application
- Confidence: high
- README title: rslashscrape
- README summary: A small local app for scraping a user-provided subreddit and surfacing posts that are performing well.
- Evidence:

  - README/package metadata points to twitter-style social application.
  - Package scripts include dev, start.
  - Environment variable names include HOST, PORT, REDDIT_CLIENT_ID, REDDIT_CLIENT_SECRET.
  - Repository structure includes ./ for root local node backend/server.

## Task Search Recipes

### Fix Env Or Deployment Issue

1. Open `.env.example` if present.
2. Open env/config files from Key Files or Feature Map.
3. Check deployment docs, migrations, and package scripts.
4. Avoid unrelated feature files unless they reference the specific env var.

## Agent Search Guide

- Read first:
  - `package.json` - Node package manifest and scripts
  - `README.md` - Project documentation
  - `server.js` - Local Node backend/server entrypoint
- Search by directory role:
  - `./` - Root local Node backend/server
  - `public/` - Static assets
- Inspect dependency hubs before leaf files:
  - `server.js` - imports 0 internal file(s), imported by 0 internal file(s)

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For configuration questions, inspect the Environment Variables section before opening env-related files.
- For risk review, start with Findings; each item names the category and usually the relevant file.

## Changes Since Previous Snapshot

- Previous snapshot: `20260625-025321`
- Current generated: `2026-06-25 03:04:05`
- Audit status: `not run` -> `not run`

- No deterministic changes were detected since the previous snapshot.

- Added routes: none
- Removed routes: none
- Added env vars: none
- Removed env vars: none
- Added findings: none
- Resolved findings: none
- Stack changes: none
- Framework changes: none
- Database changes: none
- Test signal changes: none
- Deployment signal changes: none
- Key file changes: none

## Detected Stack

- Languages: JavaScript
- Frameworks: none detected
- Libraries: none detected
- Databases: none detected
- Testing: none detected
- Deployment: none detected

## Project Structure

- `./` — Root local Node backend/server. 1 files scanned.
- `public/` — Static assets. 3 files scanned.

## Key Files

- `README.md` — Project documentation.
- `package.json` — Node package manifest and scripts.
- `server.js` — Local Node backend/server entrypoint.

## File Connections

- `server.js` — local Node backend/server entrypoint; Connected to the internal dependency graph; imports 0 internal file(s), imported by 0 internal file(s).

## Recommended Next Steps

- **medium / env**: Add a .env.example with variable names and safe placeholder values.
- **medium / deployment**: Add .env.example before deployment handoff.
- **low / tests**: Add a small smoke test or unit test suite for the critical path.
