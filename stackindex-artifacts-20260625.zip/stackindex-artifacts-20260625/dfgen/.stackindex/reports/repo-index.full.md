# StackIndex Full Repo Index

Generated: 2026-06-25 02:53:21

This is the verbose companion to `repo-index.md`. Use it when the compact search plan is not enough.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `dfgen`
- Path: `/Users/will/Workspace/dfgen`
- Files indexed: 28
- Finding summary: 0 high, 0 medium, 2 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 4
- Large files skipped: 0
- Binary files skipped: 5
- Unresolved internal imports: 0
- Internal alias imports resolved: 0
- Confidence warnings:
  - Binary files were skipped.

## Feature Map Quality

- Feature map confidence: low
- Reason: Feature Map has fewer than 2 useful compact features; use Agent Search Guide and Key Files first.
- Start with Agent Search Guide and Key Files before broad searches.

## Project Context

- Likely purpose: Developer tooling application
- Confidence: low
- README title: DFGen
- README summary: DFGen is a desktop-first, local-first face-swap application shell. The current milestone establishes the app frame, media file flow, Python worker boundary, shared job schema, progress reporting, local job history, and a still-image face detection/selection preview without implementing real face swapping.
- Evidence:

  - README/package metadata suggests this broad purpose, but evidence was not strong enough for a high-confidence domain label.

## Task Search Recipes

### Fix UI Behavior

1. Start from the matching `src/app/<feature>/page.*` or sibling component in Feature Map.
2. Search inside that feature folder and matching `src/lib/<feature>/` before shared modules.
3. Check API calls and route handlers before editing shared database code.
4. Avoid global styles/assets unless the task is visual or layout-specific.

### Fix Env Or Deployment Issue

1. Open `.env.example` if present.
2. Open env/config files from Key Files or Feature Map.
3. Check deployment docs, migrations, and package scripts.
4. Avoid unrelated feature files unless they reference the specific env var.

### Debug Worker Or Scheduled Job

1. Start from worker entries in Feature Map or Key Files.
2. Follow imports into shared config, repositories, and domain logic.
3. Check scripts and tests that mention worker, tick, queue, cron, or sync.
4. Broaden only after the worker entrypoint and its direct dependencies are understood.

## Agent Search Guide

- Read first:
  - `package.json` - Node package manifest and scripts
  - `src-tauri/Cargo.toml` - Tauri/Rust package manifest
  - `README.md` - Project documentation
  - `src/App.tsx` - Frontend application entrypoint
  - `src/main.tsx` - Frontend application entrypoint
  - `src-tauri/src/lib.rs` - Tauri/Rust backend entrypoint
  - `src-tauri/src/main.rs` - Tauri/Rust backend entrypoint
  - `src-tauri/tauri.conf.json` - Tauri application config
- Search by directory role:
  - `src-tauri/` - Tauri desktop application shell
  - `src-tauri/src/` - Tauri/Rust backend code
  - `src-tauri/capabilities/` - Tauri permissions/config
  - `src/` - Frontend/source application code
- Inspect dependency hubs before leaf files:
  - `src/App.tsx` - imports 1 internal file(s), imported by 1 internal file(s)
  - `src/main.tsx` - imports 1 internal file(s), imported by 0 internal file(s)
  - `src/shared/job.ts` - imports 0 internal file(s), imported by 1 internal file(s)

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For configuration questions, inspect the Environment Variables section before opening env-related files.
- For risk review, start with Findings; each item names the category and usually the relevant file.

## Changes Since Previous Snapshot

No previous snapshot yet. Run StackIndex again after another analysis to see changes.

## Detected Stack

- Languages: Rust, TypeScript, Python
- Frameworks: Tauri, Vite, React, Node.js
- Libraries: none detected
- Databases: none detected
- Testing: none detected
- Deployment: none detected

## Project Structure

- `src-tauri/` — Tauri desktop application shell. 11 files scanned.
- `src-tauri/src/` — Tauri/Rust backend code. 2 files scanned.
- `src-tauri/capabilities/` — Tauri permissions/config. 1 files scanned.
- `src/` — Frontend/source application code. 4 files scanned.

## Key Files

- `README.md` — Project documentation.
- `package.json` — Node package manifest and scripts.
- `src-tauri/Cargo.toml` — Tauri/Rust package manifest.
- `src-tauri/src/lib.rs` — Tauri/Rust backend entrypoint.
- `src-tauri/src/main.rs` — Tauri/Rust backend entrypoint.
- `src-tauri/tauri.conf.json` — Tauri application config.
- `src/App.tsx` — Frontend application entrypoint.
- `src/main.tsx` — Frontend application entrypoint.
- `vite.config.ts` — Vite config.
- `tsconfig.json` — TypeScript config.

## File Connections

- `src/App.tsx` — frontend application entrypoint; Entrypoint that connects to other project modules; imports 1 internal file(s), imported by 1 internal file(s).
- `src/main.tsx` — frontend application entrypoint; Entrypoint that connects to other project modules; imports 1 internal file(s), imported by 0 internal file(s).
- `src/shared/job.ts` — source file; Connected to the internal dependency graph; imports 0 internal file(s), imported by 1 internal file(s).

## Important Exports

- `worker/demo.py`
  - `main` (function)
  - `write_demo_images` (function)
  - `write_demo_job` (function)
- `worker/main.py`
  - `FaceBox` (class)
  - `FaceSwapJob` (class)
  - `detect_faces` (function)
  - `draw_face_boxes` (function)
  - `emit` (function)
  - `emit_raw` (function)
  - `import_cv2` (function)
  - `load_image` (function)
- `src/shared/job.ts`
  - `FaceBox` (type)
  - `FaceSwapJob` (type)
  - `JobRecord` (type)
  - `JobStatus` (type)
  - `MediaType` (type)
  - `Quality` (type)
  - `WorkerProgress` (type)

## Architecture Hints

- Frontend entrypoints connect to top-level UI or component modules.
- This project appears mostly frontend/static based on Vite-style entrypoints and no detected API routes.

## File Overview

- Source files: 9
- Config files: 14
- Test files: 0
- Docs: 2

## Package Scripts

- `build`: `tsc && vite build`
- `dev`: `vite --host 127.0.0.1`
- `preview`: `vite preview --host 127.0.0.1`
- `tauri`: `tauri`
- `tauri:build`: `tauri build`
- `tauri:dev`: `tauri dev`
- `worker:demo`: `python3 worker/demo.py`

## Environment Variables

- `.env.example`: no

- Required app config: none detected
- Optional app config: `TAURI_ENV_DEBUG` (missing from `.env.example`), `TAURI_ENV_PLATFORM` (missing from `.env.example`)
- Platform/build metadata: none detected
- Script-only vars: none detected
- Missing required from .env.example: none

## API Routes

No API routes detected.

## Tests

- Test files: no
- Test script: no
- Frameworks: none detected

## Deployment Readiness

- README: yes
- `.env.example`: no
- Dockerfile: no
- Vercel config: no
- Health endpoint: no
- Migration files: no

## Findings

- **low / package**: No lint script found. (`package.json`)
  Recommendation: Add a lint script for local and CI readiness.
- **low / tests**: No obvious test files were found.
  Recommendation: Add a small smoke test or unit test suite for the critical path.

## Recommended Next Steps

- **low / package**: Add a lint script for local and CI readiness.
- **low / tests**: Add a small smoke test or unit test suite for the critical path.
