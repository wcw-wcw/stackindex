# StackIndex Full Repo Index

Generated: 2026-06-25 02:53:21

This is the verbose companion to `repo-index.md`. Use it when the compact search plan is not enough.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `bladerivals`
- Path: `/Users/will/Workspace/bladerivals`
- Files indexed: 39
- Finding summary: 0 high, 0 medium, 0 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 2
- Large files skipped: 0
- Binary files skipped: 0
- Unresolved internal imports: 0
- Internal alias imports resolved: 0

## Project Context

- Likely purpose: Board-game arena application
- Confidence: low
- README title: BladeRivals
- README summary: BladeRivals is a Rojo v7 Roblox Luau prototype for a 1v1 melee arena game. The current slice focuses on a playable test loop: lobby, queue, best-of-5 duel, first-person combat, return to lobby, and enough debug feedback to playtest quickly.
- Evidence:

  - README/package metadata suggests this broad purpose, but evidence was not strong enough for a high-confidence domain label.

## Feature Map

### Client

- Start here:
  - `src/client/ClientMain.client.luau`
  - `src/client/controllers/AnimationController.luau`
  - `src/client/controllers/CameraController.luau`
  - `src/client/controllers/CombatController.luau`
  - `src/client/controllers/EffectsController.luau`
  - `src/client/controllers/FeedbackController.luau`
  - `src/client/controllers/HudController.luau`
  - `src/client/controllers/InputController.luau`
  - `src/client/controllers/MovementController.luau`
  - `src/client/controllers/SoundController.luau`
  - `src/client/controllers/ViewmodelController.luau`
  - `src/client/controllers/ViewmodelWeaponBuilder.luau`
- Related tests: none detected
- Search terms: `client`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Server

- Start here:
  - `src/server/ServerMain.server.luau`
  - `src/server/services/AbilityService.luau`
  - `src/server/services/ArenaService.luau`
  - `src/server/services/CombatService.luau`
  - `src/server/services/InventoryService.luau`
  - `src/server/services/LobbyService.luau`
  - `src/server/services/MatchService.luau`
  - `src/server/services/PersistenceService.luau`
  - `src/server/services/PlayerStateService.luau`
  - `src/server/services/ThirdPersonWeaponService.luau`
  - `src/server/services/TrainingDummyService.luau`
- Related tests: none detected
- Search terms: `server`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Shared

- Start here:
  - `src/shared/AbilityDefinitions.luau`
  - `src/shared/AnimationDefinitions.luau`
  - `src/shared/AssetDefinitions.luau`
  - `src/shared/EffectDefinitions.luau`
  - `src/shared/FeedbackDefinitions.luau`
  - `src/shared/GameConfig.luau`
  - `src/shared/MovementDefinitions.luau`
  - `src/shared/Remotes.luau`
  - `src/shared/ShopDefinitions.luau`
  - `src/shared/WeaponDefinitions.luau`
- Related tests: none detected
- Search terms: `shared`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

## Task Search Recipes

## Agent Search Guide

- Read first:
  - `README.md` - Project documentation
- Search by directory role:
  - `src/` - Frontend/source application code

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.

## Changes Since Previous Snapshot

No previous snapshot yet. Run StackIndex again after another analysis to see changes.

## Detected Stack

- Languages: none detected
- Frameworks: none detected
- Libraries: none detected
- Databases: none detected
- Testing: none detected
- Deployment: none detected

## Project Structure

- `src/` — Frontend/source application code. 33 files scanned.

## Key Files

- `README.md` — Project documentation.

## File Overview

- Source files: 0
- Config files: 3
- Test files: 0
- Docs: 3

## Package Scripts

No package scripts detected.

## Environment Variables

No environment variable usage detected.

## API Routes

No API routes detected.

## Tests

- Test files: no
- Test script: no
- Frameworks: none detected

## Deployment Readiness

- README: yes
- `.env.example`: no
- Dockerfile: no
- Vercel config: no
- Health endpoint: no
- Migration files: no

## Findings

No findings. Nice and quiet.

## Recommended Next Steps

- Keep this index current by running `stackindex analyze . --no-tui` after meaningful repository changes.
