StackIndex generated artifacts
Created: 2026-06-25
Projects: connect_four opgg folio devflow stkapp assessmentapp my-website slay-the-spire-mvp stackmap bladerivals algo rgtracker stackindex dfgen asciigen rslashscrape
Files per project: .stackindex/analysis.json, .stackindex/AGENTS.md, .stackindex/reports/repo-index.md, .stackindex/reports/repo-index.full.md
