# StackIndex Repo Index

Generated: 2026-06-25 02:53:20

This compact file is an agent-facing search plan. Read it before broad file searches so follow-up exploration can stay targeted. Open `repo-index.full.md` only when you need verbose routes, env vars, scripts, findings, or file counts.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `folio`
- Path: `/Users/will/Workspace/folio`
- Files indexed: 29
- Finding summary: 0 high, 0 medium, 1 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 4
- Large files skipped: 2
- Binary files skipped: 5
- Unresolved internal imports: 0
- Internal alias imports resolved: 0
- Confidence warnings:
  - Alias-looking imports were detected but could not be resolved from tsconfig/jsconfig paths or baseUrl.
  - Large files were skipped to keep the index compact.
  - Binary files were skipped.

## Feature Map Quality

- Feature map confidence: low
- Reason: Feature Map has fewer than 2 useful compact features; use Agent Search Guide and Key Files first.
- Start with Agent Search Guide and Key Files before broad searches.

## Project Context

- Likely purpose: Portfolio/personal site
- Confidence: high
- README title: Will West Portfolio
- README summary: A polished personal portfolio for Will West built with Next.js, TypeScript, Tailwind CSS, and Vercel-ready defaults. The site is a static, recruiter-friendly portfolio that presents featured projects, case studies, resume information, skills, and contact links.
- Evidence:

  - README/package metadata points to portfolio/personal site.
  - Package scripts include build, dev.
  - Repository structure includes docs/ for documentation.

## Task Search Recipes

### Fix UI Behavior

1. Start from the matching `src/app/<feature>/page.*` or sibling component in Feature Map.
2. Search inside that feature folder and matching `src/lib/<feature>/` before shared modules.
3. Check API calls and route handlers before editing shared database code.
4. Avoid global styles/assets unless the task is visual or layout-specific.

## Agent Search Guide

- Read first:
  - `package.json` - Node package manifest and scripts
  - `README.md` - Project documentation
  - `vercel.json` - Vercel deployment config
  - `next.config.ts` - Next.js config
  - `tsconfig.json` - TypeScript config
- Search by directory role:
  - `docs/` - Documentation
- Inspect dependency hubs before leaf files:
  - `components/container.tsx` - imports 0 internal file(s), imported by 2 internal file(s)
  - `components/footer.tsx` - imports 1 internal file(s), imported by 0 internal file(s)
  - `components/navbar.tsx` - imports 1 internal file(s), imported by 0 internal file(s)

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For risk review, start with Findings; each item names the category and usually the relevant file.

## Changes Since Previous Snapshot

No previous snapshot yet. Run StackIndex again after another analysis to see changes.

## Detected Stack

- Languages: TypeScript, JavaScript
- Frameworks: Next.js, Tailwind CSS, React, Node.js
- Libraries: none detected
- Databases: none detected
- Testing: none detected
- Deployment: Vercel

## Project Structure

- `docs/` — Documentation. 1 files scanned.

## Key Files

- `README.md` — Project documentation.
- `next.config.ts` — Next.js config.
- `package.json` — Node package manifest and scripts.
- `vercel.json` — Vercel deployment config.
- `tsconfig.json` — TypeScript config.

## File Connections

- `components/container.tsx` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 2 internal file(s).
- `components/footer.tsx` — source file; Connected to the internal dependency graph; imports 1 internal file(s), imported by 0 internal file(s).
- `components/navbar.tsx` — source file; Connected to the internal dependency graph; imports 1 internal file(s), imported by 0 internal file(s).

## Important Exports

- `components/container.tsx`
  - `Container` (function)
- `components/footer.tsx`
  - `Footer` (function)
- `components/navbar.tsx`
  - `Navbar` (function)

## Architecture Hints

- Shared modules are imported by multiple important files.

## Recommended Next Steps

- **low / tests**: Add a small smoke test or unit test suite for the critical path.
