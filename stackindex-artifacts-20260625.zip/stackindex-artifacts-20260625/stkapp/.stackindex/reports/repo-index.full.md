# StackIndex Full Repo Index

Generated: 2026-06-25 03:04:04

This is the verbose companion to `repo-index.md`. Use it when the compact search plan is not enough.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `stkapp`
- Path: `/Users/will/Workspace/stkapp`
- Files indexed: 144
- Finding summary: 0 high, 0 medium, 0 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 5
- Large files skipped: 0
- Binary files skipped: 1
- Unresolved internal imports: 0
- Internal alias imports resolved: 195
- Confidence warnings:
  - Binary files were skipped.

## Project Context

- Likely purpose: Stock monitoring and alerting application
- Confidence: high
- README title: SignalDesk
- README summary: SignalDesk is a local-first stock monitoring and alerting MVP. It lets a signed-in user maintain a small watchlist, create rule-based alerts, inspect chart data, replay candle datasets, and test notification flows. It is a research and planning tool only: it does not provide financial advice, connect to brokerage accounts, or execute trades.
- Evidence:

  - README/package metadata points to stock monitoring and alerting application.
  - Package scripts include build, db:migrate:postgres, dev, health:check.
  - Environment variable names include ALPACA_API_KEY_ID, ALPACA_API_SECRET_KEY, ALPACA_DATA_FEED, ALPACA_TRADING_BASE_URL.
  - API routes include auth, backtest, bars, channels, cleanup, datasets endpoints.
  - Repository structure includes db/migrations/ for database schema migration files.

## Feature Map

### Rules / alerts

- Start here:
  - `src/app/api/rules/[id]/route.ts`
  - `src/app/api/rules/backtest/route.ts`
  - `src/app/api/rules/preview/route.ts`
  - `src/app/api/rules/route.ts`
  - `src/app/api/rules/validate/route.ts`
  - `src/app/rules/[id]/page.tsx`
  - `src/app/rules/new/page.tsx`
  - `src/app/rules/page.tsx`
  - `src/lib/rules/backtest.ts`
  - `src/lib/rules/evaluate.ts`
  - `src/lib/rules/level-context.ts`
  - `src/lib/rules/preview.ts`
  - `src/lib/rules/schema.ts`
  - `src/lib/rules/types.ts`
  - `src/app/rules/quick-price-alert.tsx`
  - `src/app/rules/rule-manager.tsx`
- Related tests:
  - `src/lib/rules/evaluate.test.ts`
- Search terms: `rule`, `rules`, `alert`, `alerts`, `condition`, `operator`
- Routes: `DELETE /api/rules/:id`, `GET /api/rules`, `PATCH /api/rules/:id`, `POST /api/rules`, `POST /api/rules/backtest`, `POST /api/rules/preview`, `POST /api/rules/validate`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Market data

- Start here:
  - `src/app/api/market/bars/[symbol]/route.ts`
  - `src/app/api/market/diagnostics/route.ts`
  - `src/app/api/market/snapshot/[symbol]/route.ts`
  - `src/app/api/market/status/route.ts`
  - `src/lib/market/alpaca-market-data.ts`
  - `src/lib/market/chart-bars.ts`
  - `src/lib/market/diagnostics.ts`
  - `src/lib/market/indicators.ts`
  - `src/lib/market/mock-market-data.ts`
  - `src/lib/market/provider.ts`
  - `src/lib/market/status-helpers.ts`
  - `src/lib/market/types.ts`
- Related tests:
  - `src/app/api/market/bars/[symbol]/route.test.ts`
  - `src/lib/market/alpaca-market-data.test.ts`
  - `src/lib/market/chart-bars.test.ts`
  - `src/lib/market/mock-market-data.test.ts`
  - `src/lib/market/provider.test.ts`
  - `src/lib/market/status-helpers.test.ts`
- Search terms: `market`, `quote`, `quotes`, `ticker`, `symbol`, `candle`
- Routes: `GET /api/market/bars/:symbol`, `GET /api/market/diagnostics`, `GET /api/market/snapshot/:symbol`, `GET /api/market/status`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Notifications

- Start here:
  - `src/app/api/notifications/channels/[id]/route.ts`
  - `src/app/api/notifications/channels/[id]/test/route.ts`
  - `src/app/api/notifications/channels/route.ts`
  - `src/app/api/notifications/phone/start/route.ts`
  - `src/app/api/notifications/phone/verify/route.ts`
  - `src/app/api/notifications/preferences/route.ts`
  - `src/lib/notifications/notification-service.ts`
- Related tests:
  - `src/lib/notifications/notification-service.test.ts`
- Search terms: `notification`, `notifications`, `email`, `webhook`
- Routes: `DELETE /api/notifications/channels/:id`, `GET /api/notifications/channels`, `GET /api/notifications/preferences`, `PATCH /api/notifications/channels/:id`, `PATCH /api/notifications/preferences`, `POST /api/notifications/channels`, `POST /api/notifications/channels/:id/test`, `POST /api/notifications/phone/start`, `POST /api/notifications/phone/verify`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Worker

- Start here:
  - `src/app/api/worker/replay/route.ts`
  - `src/app/api/worker/start/route.ts`
  - `src/app/api/worker/status/route.ts`
  - `src/app/api/worker/stop/route.ts`
  - `src/app/api/worker/tick/route.ts`
  - `src/lib/worker/live-monitor.ts`
  - `src/lib/worker/local-mock-worker.ts`
  - `src/lib/worker/local-worker-loop.ts`
  - `src/lib/worker/status.ts`
  - `scripts/worker-status.mjs`
  - `scripts/worker.mjs`
  - `src/worker/signaldesk-worker.ts`
- Related tests:
  - `src/lib/worker/live-monitor.test.ts`
  - `src/lib/worker/status.test.ts`
- Search terms: `worker`, `tick`, `job`, `cron`, `queue`
- Routes: `GET /api/worker/status`, `POST /api/worker/replay`, `POST /api/worker/start`, `POST /api/worker/stop`, `POST /api/worker/tick`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Auth

- Start here:
  - `src/app/api/auth/login/route.ts`
  - `src/app/api/auth/logout/route.ts`
  - `src/app/api/auth/me/route.ts`
  - `src/app/api/auth/register/route.ts`
  - `src/lib/auth/password.ts`
  - `src/lib/auth/rate-limit.ts`
  - `src/lib/auth/require-user.ts`
  - `src/lib/auth/session.ts`
- Related tests: none detected
- Search terms: `auth`, `session`, `cookie`, `login`, `logout`
- Routes: `GET /api/auth/me`, `POST /api/auth/login`, `POST /api/auth/logout`, `POST /api/auth/register`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Watchlist

- Start here:
  - `src/app/api/watchlist/[symbol]/route.ts`
  - `src/app/api/watchlist/route.ts`
  - `src/app/watchlist/page.tsx`
  - `src/app/watchlist/watchlist-editor.tsx`
- Related tests: none detected
- Search terms: `watchlist`, `watchlists`, `symbol`, `ticker`
- Routes: `DELETE /api/watchlist/:symbol`, `GET /api/watchlist`, `POST /api/watchlist`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Symbol levels

- Start here:
  - `src/app/api/symbol-levels/[id]/route.ts`
  - `src/app/api/symbol-levels/route.ts`
  - `src/lib/symbol-levels.ts`
  - `src/app/symbols/[symbol]/symbol-levels-panel.tsx`
- Related tests:
  - `src/app/api/symbol-levels/[id]/route.test.ts`
  - `src/app/api/symbol-levels/route.test.ts`
- Search terms: `symbol-level`, `symbol`, `symbols`, `levels`, `targets`
- Routes: `DELETE /api/symbol-levels/:id`, `GET /api/symbol-levels`, `PATCH /api/symbol-levels/:id`, `POST /api/symbol-levels`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Replay

- Start here:
  - `src/app/api/replay/datasets/[id]/route.ts`
  - `src/app/api/replay/datasets/route.ts`
  - `src/app/api/worker/replay/route.ts`
  - `src/app/replay/page.tsx`
  - `src/lib/replay/candle-dataset.ts`
  - `src/app/replay/replay-lab.tsx`
- Related tests:
  - `src/lib/replay/candle-dataset.test.ts`
- Search terms: `replay`
- Routes: `DELETE /api/replay/datasets/:id`, `GET /api/replay/datasets`, `POST /api/replay/datasets`, `POST /api/worker/replay`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Health

- Start here:
  - `src/app/api/health/deep/route.ts`
  - `src/app/api/health/route.ts`
  - `src/lib/health.ts`
  - `scripts/health-check.mjs`
- Related tests:
  - `src/app/api/health/deep/route.test.ts`
  - `src/lib/health.test.ts`
- Search terms: `health`
- Routes: `GET /api/health`, `GET /api/health/deep`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Channel

- Start here:
  - `src/app/api/notifications/channels/[id]/route.ts`
  - `src/app/api/notifications/channels/[id]/test/route.ts`
  - `src/app/api/notifications/channels/route.ts`
- Related tests: none detected
- Search terms: `channel`
- Routes: `DELETE /api/notifications/channels/:id`, `GET /api/notifications/channels`, `PATCH /api/notifications/channels/:id`, `POST /api/notifications/channels`, `POST /api/notifications/channels/:id/test`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Level

- Start here:
  - `src/app/api/symbol-levels/[id]/route.ts`
  - `src/app/api/symbol-levels/route.ts`
- Related tests: none detected
- Search terms: `level`
- Routes: `DELETE /api/symbol-levels/:id`, `GET /api/symbol-levels`, `PATCH /api/symbol-levels/:id`, `POST /api/symbol-levels`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Phone

- Start here:
  - `src/app/api/notifications/phone/start/route.ts`
  - `src/app/api/notifications/phone/verify/route.ts`
- Related tests: none detected
- Search terms: `phone`
- Routes: `POST /api/notifications/phone/start`, `POST /api/notifications/phone/verify`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Bars

- Start here:
  - `src/app/api/market/bars/[symbol]/route.ts`
- Related tests:
  - `src/app/api/market/bars/[symbol]/route.test.ts`
  - `src/lib/market/chart-bars.test.ts`
- Search terms: `bars`
- Routes: `GET /api/market/bars/:symbol`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Dataset

- Start here:
  - `src/app/api/replay/datasets/[id]/route.ts`
  - `src/app/api/replay/datasets/route.ts`
- Related tests:
  - `src/lib/replay/candle-dataset.test.ts`
- Search terms: `dataset`
- Routes: `DELETE /api/replay/datasets/:id`, `GET /api/replay/datasets`, `POST /api/replay/datasets`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Login

- Start here:
  - `src/app/api/auth/login/route.ts`
  - `src/app/login/page.tsx`
  - `src/app/login/auth-form.tsx`
- Related tests: none detected
- Search terms: `login`
- Routes: `POST /api/auth/login`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Maintenance

- Start here:
  - `src/app/api/maintenance/cleanup/route.ts`
  - `src/lib/maintenance/cleanup.ts`
- Related tests:
  - `src/lib/maintenance/cleanup.test.ts`
- Search terms: `maintenance`
- Routes: `POST /api/maintenance/cleanup`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Deep

- Start here:
  - `src/app/api/health/deep/route.ts`
- Related tests:
  - `src/app/api/health/deep/route.test.ts`
- Search terms: `deep`
- Routes: `GET /api/health/deep`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Cleanup

- Start here:
  - `src/app/api/maintenance/cleanup/route.ts`
- Related tests:
  - `src/lib/maintenance/cleanup.test.ts`
- Search terms: `cleanup`
- Routes: `POST /api/maintenance/cleanup`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Diagnostic

- Start here:
  - `src/app/api/market/diagnostics/route.ts`
  - `src/app/diagnostics/page.tsx`
  - `src/app/diagnostics/maintenance-cleanup-card.tsx`
- Related tests: none detected
- Search terms: `diagnostic`
- Routes: `GET /api/market/diagnostics`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: high

### Backtest

- Start here:
  - `src/app/api/rules/backtest/route.ts`
- Related tests: none detected
- Search terms: `backtest`
- Routes: `POST /api/rules/backtest`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Logout

- Start here:
  - `src/app/api/auth/logout/route.ts`
- Related tests: none detected
- Search terms: `logout`
- Routes: `POST /api/auth/logout`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Preference

- Start here:
  - `src/app/api/notifications/preferences/route.ts`
- Related tests: none detected
- Search terms: `preference`
- Routes: `GET /api/notifications/preferences`, `PATCH /api/notifications/preferences`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Preview

- Start here:
  - `src/app/api/rules/preview/route.ts`
- Related tests: none detected
- Search terms: `preview`
- Routes: `POST /api/rules/preview`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Register

- Start here:
  - `src/app/api/auth/register/route.ts`
- Related tests: none detected
- Search terms: `register`
- Routes: `POST /api/auth/register`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Snapshot

- Start here:
  - `src/app/api/market/snapshot/[symbol]/route.ts`
- Related tests: none detected
- Search terms: `snapshot`
- Routes: `GET /api/market/snapshot/:symbol`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Statu

- Start here:
  - `src/app/api/market/status/route.ts`
  - `src/app/api/worker/status/route.ts`
- Related tests: none detected
- Search terms: `statu`
- Routes: `GET /api/market/status`, `GET /api/worker/status`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Tick

- Start here:
  - `src/app/api/worker/tick/route.ts`
- Related tests: none detected
- Search terms: `tick`
- Routes: `POST /api/worker/tick`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

## Task Search Recipes

### Fix API Behavior

1. Open the matching file in API Routes or Route Implementation Chains.
2. Follow the listed imports into shared `src/lib/`, database, schema, or validation files.
3. Open the nearest related test from Feature Map or Route Implementation Chains.
4. Broaden to whole-repo search only after route, schema, storage, and tests are checked.

### Fix UI Behavior

1. Start from the matching `src/app/<feature>/page.*` or sibling component in Feature Map.
2. Search inside that feature folder and matching `src/lib/<feature>/` before shared modules.
3. Check API calls and route handlers before editing shared database code.
4. Avoid global styles/assets unless the task is visual or layout-specific.

### Fix Env Or Deployment Issue

1. Open `.env.example` if present.
2. Open env/config files from Key Files or Feature Map.
3. Check deployment docs, migrations, and package scripts.
4. Avoid unrelated feature files unless they reference the specific env var.

### Debug Worker Or Scheduled Job

1. Start from worker entries in Feature Map or Key Files.
2. Follow imports into shared config, repositories, and domain logic.
3. Check scripts and tests that mention worker, tick, queue, cron, or sync.
4. Broaden only after the worker entrypoint and its direct dependencies are understood.

## Route Implementation Chains

- `POST /api/auth/login`
  - Follow:
    - `src/app/api/auth/login/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/password.ts`
    - `src/lib/auth/rate-limit.ts`
    - `src/lib/auth/session.ts`
- `POST /api/auth/logout`
  - Follow:
    - `src/app/api/auth/logout/route.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/db/postgres-repositories.ts`
    - `src/lib/db/provider.ts`
- `GET /api/auth/me`
  - Follow:
    - `src/app/api/auth/me/route.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/db/postgres-repositories.ts`
    - `src/lib/db/provider.ts`
- `POST /api/auth/register`
  - Follow:
    - `src/app/api/auth/register/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/password.ts`
    - `src/lib/auth/rate-limit.ts`
    - `src/lib/auth/session.ts`
- `GET /api/health`
  - Follow:
    - `src/app/api/health/route.ts`
    - `src/lib/health.ts`
    - `src/lib/db/provider.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/market/provider.ts`
  - Tests:
    - `src/app/api/health/deep/route.test.ts`
    - `src/lib/health.test.ts`
- `GET /api/health/deep`
  - Follow:
    - `src/app/api/health/deep/route.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/health.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/db/provider.ts`
  - Tests:
    - `src/app/api/health/deep/route.test.ts`
    - `src/lib/health.test.ts`
- `POST /api/maintenance/cleanup`
  - Follow:
    - `src/app/api/maintenance/cleanup/route.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/maintenance/cleanup.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/db/postgres-repositories.ts`
  - Tests:
    - `src/lib/maintenance/cleanup.test.ts`
- `GET /api/market/bars/:symbol`
  - Follow:
    - `src/app/api/market/bars/[symbol]/route.ts`
    - `src/lib/market/provider.ts`
    - `src/lib/market/chart-bars.ts`
    - `src/lib/rules/types.ts`
    - `src/lib/config/env.ts`
  - Tests:
    - `src/app/api/market/bars/[symbol]/route.test.ts`
    - `src/lib/market/alpaca-market-data.test.ts`
    - `src/lib/market/chart-bars.test.ts`
    - `src/lib/market/mock-market-data.test.ts`
    - `src/lib/market/provider.test.ts`
- `GET /api/market/diagnostics`
  - Follow:
    - `src/app/api/market/diagnostics/route.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/market/diagnostics.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/db/provider.ts`
  - Tests:
    - `src/app/api/market/bars/[symbol]/route.test.ts`
    - `src/lib/market/alpaca-market-data.test.ts`
    - `src/lib/market/chart-bars.test.ts`
    - `src/lib/market/mock-market-data.test.ts`
    - `src/lib/market/provider.test.ts`
- `GET /api/market/snapshot/:symbol`
  - Follow:
    - `src/app/api/market/snapshot/[symbol]/route.ts`
    - `src/lib/market/provider.ts`
    - `src/lib/rules/types.ts`
    - `src/lib/config/env.ts`
    - `src/lib/market/alpaca-market-data.ts`
  - Tests:
    - `src/app/api/market/bars/[symbol]/route.test.ts`
    - `src/lib/market/alpaca-market-data.test.ts`
    - `src/lib/market/chart-bars.test.ts`
    - `src/lib/market/mock-market-data.test.ts`
    - `src/lib/market/provider.test.ts`
- `GET /api/market/status`
  - Follow:
    - `src/app/api/market/status/route.ts`
    - `src/lib/market/provider.ts`
    - `src/lib/config/env.ts`
    - `src/lib/market/alpaca-market-data.ts`
    - `src/lib/market/mock-market-data.ts`
  - Tests:
    - `src/app/api/market/bars/[symbol]/route.test.ts`
    - `src/lib/market/alpaca-market-data.test.ts`
    - `src/lib/market/chart-bars.test.ts`
    - `src/lib/market/mock-market-data.test.ts`
    - `src/lib/market/provider.test.ts`
- `GET /api/notifications/channels`
  - Follow:
    - `src/app/api/notifications/channels/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/db/postgres-repositories.ts`
    - `src/lib/db/provider.ts`
  - Tests:
    - `src/lib/notifications/notification-service.test.ts`
- `POST /api/notifications/channels`
  - Follow:
    - `src/app/api/notifications/channels/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/db/postgres-repositories.ts`
    - `src/lib/db/provider.ts`
  - Tests:
    - `src/lib/notifications/notification-service.test.ts`
- `DELETE /api/notifications/channels/:id`
  - Follow:
    - `src/app/api/notifications/channels/[id]/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/db/postgres-repositories.ts`
    - `src/lib/db/provider.ts`
  - Tests:
    - `src/lib/notifications/notification-service.test.ts`
- `PATCH /api/notifications/channels/:id`
  - Follow:
    - `src/app/api/notifications/channels/[id]/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/db/postgres-repositories.ts`
    - `src/lib/db/provider.ts`
  - Tests:
    - `src/lib/notifications/notification-service.test.ts`
- `POST /api/notifications/channels/:id/test`
  - Follow:
    - `src/app/api/notifications/channels/[id]/test/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/notifications/notification-service.ts`
    - `src/lib/db/postgres-repositories.ts`
  - Tests:
    - `src/lib/notifications/notification-service.test.ts`
- `POST /api/notifications/phone/start`
  - Follow:
    - `src/app/api/notifications/phone/start/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/db/postgres-repositories.ts`
    - `src/lib/db/provider.ts`
  - Tests:
    - `src/lib/notifications/notification-service.test.ts`
- `POST /api/notifications/phone/verify`
  - Follow:
    - `src/app/api/notifications/phone/verify/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/db/postgres-repositories.ts`
    - `src/lib/db/provider.ts`
  - Tests:
    - `src/lib/notifications/notification-service.test.ts`
- `GET /api/notifications/preferences`
  - Follow:
    - `src/app/api/notifications/preferences/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/db/postgres-repositories.ts`
    - `src/lib/db/provider.ts`
  - Tests:
    - `src/lib/notifications/notification-service.test.ts`
- `PATCH /api/notifications/preferences`
  - Follow:
    - `src/app/api/notifications/preferences/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/db/postgres-repositories.ts`
    - `src/lib/db/provider.ts`
  - Tests:
    - `src/lib/notifications/notification-service.test.ts`
- `GET /api/replay/datasets`
  - Follow:
    - `src/app/api/replay/datasets/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/replay/candle-dataset.ts`
    - `src/lib/db/postgres-repositories.ts`
  - Tests:
    - `src/lib/replay/candle-dataset.test.ts`
- `POST /api/replay/datasets`
  - Follow:
    - `src/app/api/replay/datasets/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/replay/candle-dataset.ts`
    - `src/lib/db/postgres-repositories.ts`
  - Tests:
    - `src/lib/replay/candle-dataset.test.ts`
- `DELETE /api/replay/datasets/:id`
  - Follow:
    - `src/app/api/replay/datasets/[id]/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/db/postgres-repositories.ts`
    - `src/lib/db/provider.ts`
  - Tests:
    - `src/lib/replay/candle-dataset.test.ts`
- `GET /api/rules`
  - Follow:
    - `src/app/api/rules/route.ts`
    - `src/lib/rules/schema.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/rules/level-context.ts`
  - Tests:
    - `src/lib/rules/evaluate.test.ts`
- `POST /api/rules`
  - Follow:
    - `src/app/api/rules/route.ts`
    - `src/lib/rules/schema.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/rules/level-context.ts`
  - Tests:
    - `src/lib/rules/evaluate.test.ts`
- `DELETE /api/rules/:id`
  - Follow:
    - `src/app/api/rules/[id]/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/db/postgres-repositories.ts`
    - `src/lib/db/provider.ts`
  - Tests:
    - `src/lib/rules/evaluate.test.ts`
- `PATCH /api/rules/:id`
  - Follow:
    - `src/app/api/rules/[id]/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/db/postgres-repositories.ts`
    - `src/lib/db/provider.ts`
  - Tests:
    - `src/lib/rules/evaluate.test.ts`
- `POST /api/rules/backtest`
  - Follow:
    - `src/app/api/rules/backtest/route.ts`
    - `src/lib/rules/schema.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/market/provider.ts`
    - `src/lib/rules/backtest.ts`
  - Tests:
    - `src/lib/rules/evaluate.test.ts`
- `POST /api/rules/preview`
  - Follow:
    - `src/app/api/rules/preview/route.ts`
    - `src/lib/rules/schema.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/rules/level-context.ts`
    - `src/lib/rules/preview.ts`
  - Tests:
    - `src/lib/rules/evaluate.test.ts`
- `POST /api/rules/validate`
  - Follow:
    - `src/app/api/rules/validate/route.ts`
    - `src/lib/rules/schema.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/rules/level-context.ts`
    - `src/lib/rules/types.ts`
  - Tests:
    - `src/lib/rules/evaluate.test.ts`
- `GET /api/symbol-levels`
  - Follow:
    - `src/app/api/symbol-levels/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/rules/types.ts`
    - `src/lib/symbol-levels.ts`
  - Tests:
    - `src/app/api/symbol-levels/[id]/route.test.ts`
    - `src/app/api/symbol-levels/route.test.ts`
- `POST /api/symbol-levels`
  - Follow:
    - `src/app/api/symbol-levels/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/rules/types.ts`
    - `src/lib/symbol-levels.ts`
  - Tests:
    - `src/app/api/symbol-levels/[id]/route.test.ts`
    - `src/app/api/symbol-levels/route.test.ts`
- `DELETE /api/symbol-levels/:id`
  - Follow:
    - `src/app/api/symbol-levels/[id]/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/symbol-levels.ts`
    - `src/lib/db/postgres-repositories.ts`
  - Tests:
    - `src/app/api/symbol-levels/[id]/route.test.ts`
    - `src/app/api/symbol-levels/route.test.ts`
- `PATCH /api/symbol-levels/:id`
  - Follow:
    - `src/app/api/symbol-levels/[id]/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/symbol-levels.ts`
    - `src/lib/db/postgres-repositories.ts`
  - Tests:
    - `src/app/api/symbol-levels/[id]/route.test.ts`
    - `src/app/api/symbol-levels/route.test.ts`
- `GET /api/watchlist`
  - Follow:
    - `src/app/api/watchlist/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/rules/types.ts`
    - `src/lib/db/postgres-repositories.ts`
- `POST /api/watchlist`
  - Follow:
    - `src/app/api/watchlist/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/rules/types.ts`
    - `src/lib/db/postgres-repositories.ts`
- `DELETE /api/watchlist/:symbol`
  - Follow:
    - `src/app/api/watchlist/[symbol]/route.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/rules/types.ts`
    - `src/lib/db/postgres-repositories.ts`
- `POST /api/worker/replay`
  - Follow:
    - `src/app/api/worker/replay/route.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/worker/local-mock-worker.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/market/provider.ts`
  - Tests:
    - `src/lib/replay/candle-dataset.test.ts`
    - `src/lib/worker/live-monitor.test.ts`
    - `src/lib/worker/status.test.ts`
- `POST /api/worker/start`
  - Follow:
    - `src/app/api/worker/start/route.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/worker/local-worker-loop.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/market/provider.ts`
  - Tests:
    - `src/lib/worker/live-monitor.test.ts`
    - `src/lib/worker/status.test.ts`
- `GET /api/worker/status`
  - Follow:
    - `src/app/api/worker/status/route.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/worker/local-worker-loop.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/market/provider.ts`
  - Tests:
    - `src/lib/worker/live-monitor.test.ts`
    - `src/lib/worker/status.test.ts`
- `POST /api/worker/stop`
  - Follow:
    - `src/app/api/worker/stop/route.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/worker/local-worker-loop.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/market/provider.ts`
  - Tests:
    - `src/lib/worker/live-monitor.test.ts`
    - `src/lib/worker/status.test.ts`
- `POST /api/worker/tick`
  - Follow:
    - `src/app/api/worker/tick/route.ts`
    - `src/lib/auth/session.ts`
    - `src/lib/worker/local-mock-worker.ts`
    - `src/lib/db/repositories.ts`
    - `src/lib/market/provider.ts`
  - Tests:
    - `src/lib/worker/live-monitor.test.ts`
    - `src/lib/worker/status.test.ts`

## Agent Search Guide

- Read first:
  - `package.json` - Node package manifest and scripts
  - `README.md` - Project documentation
  - `src/app/api/health/deep/route.ts` - Health endpoint implementation
  - `src/app/api/health/route.ts` - Health endpoint implementation
  - `src/app/api/auth/login/route.ts` - API route handler
  - `src/app/api/auth/logout/route.ts` - API route handler
  - `src/app/api/auth/me/route.ts` - API route handler
  - `docs/deployment-checklist.md` - Deployment documentation
- Search by directory role:
  - `db/migrations/` - Database schema migration files
  - `src/app/api/` - Next.js API route handlers
  - `src/lib/` - Shared library/application code
  - `db/` - Database schema/migrations
  - `scripts/` - Operational scripts/tooling
  - `src/` - Frontend/source application code
- Inspect dependency hubs before leaf files:
  - `src/lib/db/repositories.ts` - imports 4 internal file(s), imported by 45 internal file(s)
  - `src/lib/rules/types.ts` - imports 0 internal file(s), imported by 36 internal file(s)
  - `src/lib/auth/session.ts` - imports 1 internal file(s), imported by 32 internal file(s)
  - `src/lib/market/provider.ts` - imports 4 internal file(s), imported by 13 internal file(s)
  - `src/lib/worker/local-mock-worker.ts` - imports 10 internal file(s), imported by 6 internal file(s)

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For API behavior, start from the API Routes section and follow imports from each route file.
- For configuration questions, inspect the Environment Variables section before opening env-related files.
- For expected behavior, use the Tests section to find representative test files and scripts.

## Changes Since Previous Snapshot

- Previous snapshot: `20260625-025320`
- Current generated: `2026-06-25 03:04:04`
- Audit status: `not run` -> `not run`

- No deterministic changes were detected since the previous snapshot.

- Added routes: none
- Removed routes: none
- Added env vars: none
- Removed env vars: none
- Added findings: none
- Resolved findings: none
- Stack changes: none
- Framework changes: none
- Database changes: none
- Test signal changes: none
- Deployment signal changes: none
- Key file changes: none

## Detected Stack

- Languages: TypeScript, JavaScript
- Frameworks: Next.js, React, Node.js
- Libraries: none detected
- Databases: PostgreSQL
- Testing: Vitest
- Deployment: Vercel

## Project Structure

- `db/migrations/` — Database schema migration files. 2 files scanned.
- `src/app/api/` — Next.js API route handlers. 37 files scanned.
- `src/lib/` — Shared library/application code. 54 files scanned.
- `db/` — Database schema/migrations. 3 files scanned.
- `scripts/` — Operational scripts/tooling. 10 files scanned.
- `src/` — Frontend/source application code. 117 files scanned.
- `src/app/` — Next.js app routes/pages. 62 files scanned.
- `docs/` — Documentation. 4 files scanned.

## Key Files

- `.env.example` — Environment variable template.
- `README.md` — Project documentation.
- `next.config.ts` — Next.js config.
- `package.json` — Node package manifest and scripts.
- `src/app/api/health/deep/route.ts` — Health endpoint implementation.
- `src/app/api/health/route.ts` — Health endpoint implementation.
- `db/migrations/001_initial.sql` — Database migration.
- `db/migrations/002_symbol_levels.sql` — Database migration.
- `docs/deployment-checklist.md` — Deployment documentation.
- `docs/deployment-prep.md` — Deployment documentation.

## File Connections

- `src/lib/db/repositories.ts` — source file; Shared module imported by multiple files; imports 4 internal file(s), imported by 45 internal file(s).
- `src/lib/rules/types.ts` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 36 internal file(s).
- `src/lib/auth/session.ts` — source file; Shared module imported by multiple files; imports 1 internal file(s), imported by 32 internal file(s).
- `src/lib/market/provider.ts` — source file; Shared module imported by multiple files; imports 4 internal file(s), imported by 13 internal file(s).
- `src/lib/worker/local-mock-worker.ts` — background/worker process; Entrypoint that connects to other project modules; imports 10 internal file(s), imported by 6 internal file(s).
- `src/lib/config/env.ts` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 12 internal file(s).
- `src/lib/auth/require-user.ts` — source file; Shared module imported by multiple files; imports 1 internal file(s), imported by 9 internal file(s).
- `src/lib/rules/level-context.ts` — source file; Shared module imported by multiple files; imports 3 internal file(s), imported by 7 internal file(s).
- `src/lib/symbol-levels.ts` — source file; Shared module imported by multiple files; imports 1 internal file(s), imported by 9 internal file(s).
- `src/lib/health.ts` — source file; Shared module imported by multiple files; imports 6 internal file(s), imported by 3 internal file(s).

## Important Exports

- `src/lib/db/repositories.ts`
  - `getRepository` (function)
  - `getRepositoryProvider` (function)
  - `addWatchlistSymbol` (value)
  - `countAlertsToday` (value)
  - `countNotificationAttemptsToday` (value)
  - `countProviderErrorsSince` (value)
  - `createAlertEvent` (value)
  - `createNotificationChannel` (value)
- `src/lib/auth/session.ts`
  - `createSession` (function)
  - `deleteSession` (function)
  - `getCurrentUser` (function)
  - `SessionUser` (type)
- `src/lib/market/provider.ts`
  - `resolveMarketDataProviderMode` (function)
  - `MarketDataProviderMode` (type)
  - `activeMarketDataProvider` (value)
  - `configuredMarketDataProvider` (value)
  - `marketData` (value)
  - `marketDataProviderMode` (value)
- `src/lib/db/postgres-repositories.ts`
  - `addWatchlistSymbol` (function)
  - `countAlertsToday` (function)
  - `countNotificationAttemptsToday` (function)
  - `countProviderErrorsSince` (function)
  - `createAlertEvent` (function)
  - `createNotificationChannel` (function)
  - `createNotificationLog` (function)
  - `createProviderErrorLog` (function)
- `src/lib/rules/schema.ts`
  - `isPriceTargetCondition` (function)
  - `validateAlertRule` (function)
  - `alertRuleSchema` (value)
  - `isPriceLikeIndicator` (value)
- `src/lib/db/provider.ts`
  - `assertSqliteRepositoryProvider` (function)
  - `getDatabaseProviderDiagnostics` (function)
  - `resolveDatabaseProviderMode` (function)
  - `DatabaseProviderMode` (type)
  - `RepositoryAdapterName` (type)
- `src/app/api/worker/replay/route.ts`
  - `POST` (function)
- `src/app/api/worker/status/route.ts`
  - `GET` (function)
- `src/app/api/worker/tick/route.ts`
  - `POST` (function)
- `src/lib/worker/local-mock-worker.ts`
  - `calculateAvailablePerformance` (function)
  - `getLiveWorkerBackoffStatus` (function)
  - `resetLiveWorkerBackoff` (function)
  - `runLocalMockWorkerTick` (function)
  - `runLocalReplay` (function)
  - `runReplayDataset` (function)
  - `sendRuleNotifications` (function)
  - `WorkerReplayResult` (type)
- `src/app/api/rules/validate/route.ts`
  - `POST` (function)
- `src/lib/rules/types.ts`
  - `AlertRule` (type)
  - `BacktestResult` (type)
  - `Candle` (type)
  - `CustomPriceTarget` (type)
  - `ForwardStat` (type)
  - `Indicator` (type)
  - `IndicatorState` (type)
  - `IndicatorTarget` (type)

## Architecture Hints

- API route files import shared library or database-related code.
- Worker or operational scripts connect to shared application modules.
- Database migration files are present alongside database-related scripts.
- Shared modules are imported by multiple important files.

## File Overview

- Source files: 107
- Config files: 8
- Test files: 22
- Docs: 6

## Package Scripts

- `build`: `next build`
- `config:check`: `node --disable-warning=MODULE_TYPELESS_PACKAGE_JSON --experimental-strip-types scripts/check-env.mjs`
- `db:migrate:postgres`: `node --disable-warning=MODULE_TYPELESS_PACKAGE_JSON --experimental-strip-types scripts/db-migrate-postgres.mjs`
- `db:schema:check`: `node --disable-warning=MODULE_TYPELESS_PACKAGE_JSON --experimental-strip-types scripts/schema-parity.mjs`
- `db:status`: `node --disable-warning=MODULE_TYPELESS_PACKAGE_JSON --experimental-strip-types scripts/db-status.mjs`
- `dev`: `next dev`
- `health:check`: `node scripts/health-check.mjs`
- `lint`: `next lint`
- `smoke:local`: `node scripts/smoke-local.mjs`
- `start`: `next start`
- `test`: `vitest run`
- `worker`: `node --disable-warning=MODULE_TYPELESS_PACKAGE_JSON --experimental-strip-types scripts/worker.mjs`
- `worker:once`: `node --disable-warning=MODULE_TYPELESS_PACKAGE_JSON --experimental-strip-types scripts/worker.mjs --once`
- `worker:status`: `node --disable-warning=MODULE_TYPELESS_PACKAGE_JSON --experimental-strip-types scripts/worker-status.mjs`

## Environment Variables

- `.env.example`: yes

- Required app config: none detected
- Optional app config: `LOCAL_WORKER_INTERVAL_MS` (missing from `.env.example`), `STANDALONE_WORKER_INTERVAL_MS` (missing from `.env.example`)
- Platform/build metadata: `BUILD_TIME` (detected but likely platform/build provided), `GIT_COMMIT_SHA` (detected but likely platform/build provided), `NEXT_PUBLIC_BUILD_TIME` (detected but likely platform/build provided), `NODE_ENV` (detected but likely platform/build provided), `RENDER_GIT_COMMIT` (detected but likely platform/build provided), `VERCEL_GIT_COMMIT_SHA` (detected but likely platform/build provided)
- Script-only vars: `DATABASE_URL`, `HEALTH_BASE_URL` (missing from `.env.example`), `SIGNALDESK_BASE_URL` (missing from `.env.example`)
- Missing required from .env.example: none

## API Routes

- `POST /api/auth/login` in `src/app/api/auth/login/route.ts` (high confidence)
- `POST /api/auth/logout` in `src/app/api/auth/logout/route.ts` (high confidence)
- `GET /api/auth/me` in `src/app/api/auth/me/route.ts` (high confidence)
- `POST /api/auth/register` in `src/app/api/auth/register/route.ts` (high confidence)
- `GET /api/health` in `src/app/api/health/route.ts` (high confidence)
- `GET /api/health/deep` in `src/app/api/health/deep/route.ts` (high confidence)
- `POST /api/maintenance/cleanup` in `src/app/api/maintenance/cleanup/route.ts` (high confidence)
- `GET /api/market/bars/:symbol` in `src/app/api/market/bars/[symbol]/route.ts` (high confidence)
- `GET /api/market/diagnostics` in `src/app/api/market/diagnostics/route.ts` (high confidence)
- `GET /api/market/snapshot/:symbol` in `src/app/api/market/snapshot/[symbol]/route.ts` (high confidence)
- `GET /api/market/status` in `src/app/api/market/status/route.ts` (high confidence)
- `GET /api/notifications/channels` in `src/app/api/notifications/channels/route.ts` (high confidence)
- `POST /api/notifications/channels` in `src/app/api/notifications/channels/route.ts` (high confidence)
- `DELETE /api/notifications/channels/:id` in `src/app/api/notifications/channels/[id]/route.ts` (high confidence)
- `PATCH /api/notifications/channels/:id` in `src/app/api/notifications/channels/[id]/route.ts` (high confidence)
- `POST /api/notifications/channels/:id/test` in `src/app/api/notifications/channels/[id]/test/route.ts` (high confidence)
- `POST /api/notifications/phone/start` in `src/app/api/notifications/phone/start/route.ts` (high confidence)
- `POST /api/notifications/phone/verify` in `src/app/api/notifications/phone/verify/route.ts` (high confidence)
- `GET /api/notifications/preferences` in `src/app/api/notifications/preferences/route.ts` (high confidence)
- `PATCH /api/notifications/preferences` in `src/app/api/notifications/preferences/route.ts` (high confidence)
- `GET /api/replay/datasets` in `src/app/api/replay/datasets/route.ts` (high confidence)
- `POST /api/replay/datasets` in `src/app/api/replay/datasets/route.ts` (high confidence)
- `DELETE /api/replay/datasets/:id` in `src/app/api/replay/datasets/[id]/route.ts` (high confidence)
- `GET /api/rules` in `src/app/api/rules/route.ts` (high confidence)
- `POST /api/rules` in `src/app/api/rules/route.ts` (high confidence)
- `DELETE /api/rules/:id` in `src/app/api/rules/[id]/route.ts` (high confidence)
- `PATCH /api/rules/:id` in `src/app/api/rules/[id]/route.ts` (high confidence)
- `POST /api/rules/backtest` in `src/app/api/rules/backtest/route.ts` (high confidence)
- `POST /api/rules/preview` in `src/app/api/rules/preview/route.ts` (high confidence)
- `POST /api/rules/validate` in `src/app/api/rules/validate/route.ts` (high confidence)
- `GET /api/symbol-levels` in `src/app/api/symbol-levels/route.ts` (high confidence)
- `POST /api/symbol-levels` in `src/app/api/symbol-levels/route.ts` (high confidence)
- `DELETE /api/symbol-levels/:id` in `src/app/api/symbol-levels/[id]/route.ts` (high confidence)
- `PATCH /api/symbol-levels/:id` in `src/app/api/symbol-levels/[id]/route.ts` (high confidence)
- `GET /api/watchlist` in `src/app/api/watchlist/route.ts` (high confidence)
- `POST /api/watchlist` in `src/app/api/watchlist/route.ts` (high confidence)
- `DELETE /api/watchlist/:symbol` in `src/app/api/watchlist/[symbol]/route.ts` (high confidence)
- `POST /api/worker/replay` in `src/app/api/worker/replay/route.ts` (high confidence)
- `POST /api/worker/start` in `src/app/api/worker/start/route.ts` (high confidence)
- `GET /api/worker/status` in `src/app/api/worker/status/route.ts` (high confidence)
- `POST /api/worker/stop` in `src/app/api/worker/stop/route.ts` (high confidence)
- `POST /api/worker/tick` in `src/app/api/worker/tick/route.ts` (high confidence)

## Tests

- Test files: yes
- Test script: yes
- Frameworks: Vitest

## Deployment Readiness

- README: yes
- `.env.example`: yes
- Dockerfile: no
- Vercel config: no
- Health endpoint: yes
- Migration files: yes

## Findings

No findings. Nice and quiet.

## Recommended Next Steps

- Keep this index current by running `stackindex analyze . --no-tui` after meaningful repository changes.
