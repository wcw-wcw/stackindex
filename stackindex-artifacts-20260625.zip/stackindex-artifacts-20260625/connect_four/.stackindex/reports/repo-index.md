# StackIndex Repo Index

Generated: 2026-06-25 03:04:03

This compact file is an agent-facing search plan. Read it before broad file searches so follow-up exploration can stay targeted. Open `repo-index.full.md` only when you need verbose routes, env vars, scripts, findings, or file counts.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `connect_four`
- Path: `/Users/will/Workspace/connect_four`
- Files indexed: 55
- Finding summary: 0 high, 1 medium, 3 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 5
- Large files skipped: 0
- Binary files skipped: 40
- Unresolved internal imports: 0
- Internal alias imports resolved: 0
- Confidence warnings:
  - Binary files were skipped.

## Project Context

- Likely purpose: Board-game/game arena application
- Confidence: high
- README title: BoardArena
- README summary: BoardArena is a local-first AI board-game arena built with React, Vite, TypeScript, and FastAPI. It is designed as a portfolio-ready full-stack app: the frontend delivers a polished multi-game experience, while the backend owns game sessions, legal move validation, state transitions, scoring, and AI move selection.
- Evidence:

  - README/package metadata points to board-game/game arena application.
  - Package scripts include frontend:build, frontend:dev, frontend:test:smoke, smoke:production.
  - Environment variable names include ALLOWED_ORIGINS, APP_ENV, CI, DEV.
  - API routes include ai, backend, health, human, id}, moves endpoints.
  - Repository structure includes backend/ for backend service.

## Feature Map

### Main

- Start here:
  - `backend/app/main.py`
- Related tests: none detected
- Search terms: `main`
- Routes: `GET /_backend/api/health`, `GET /_backend/health`, `GET /api/health`, `GET /health`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Health

- Start here:
  - `backend/app/main.py`
- Related tests: none detected
- Search terms: `health`
- Routes: `GET /_backend/api/health`, `GET /_backend/health`, `GET /api/health`, `GET /health`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Id}

- Start here:
  - `backend/app/api/routes/games.py`
- Related tests: none detected
- Search terms: `id}`
- Routes: `GET /{game_id}`, `POST /{game_id}/moves/ai`, `POST /{game_id}/moves/human`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### {game

- Start here:
  - `backend/app/api/routes/games.py`
- Related tests: none detected
- Search terms: `{game`
- Routes: `GET /{game_id}`, `POST /{game_id}/moves/ai`, `POST /{game_id}/moves/human`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Game

- Start here:
  - `frontend/src/api/games.ts`
  - `backend/game/__init__.py`
  - `backend/game/ai.py`
  - `backend/game/connect4.py`
  - `backend/game/reversi.py`
  - `backend/game/reversi_ai.py`
  - `backend/game/tictactoe.py`
  - `backend/game/tictactoe_ai.py`
- Related tests: none detected
- Search terms: `game`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Service

- Start here:
  - `backend/app/services/__init__.py`
  - `backend/app/services/ai_service.py`
  - `backend/app/services/game_manager.py`
- Related tests: none detected
- Search terms: `service`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Backend

- Start here:
  - `backend/app/main.py`
- Related tests: none detected
- Search terms: `backend`
- Routes: `GET /_backend/api/health`, `GET /_backend/health`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Move

- Start here:
  - `backend/app/api/routes/games.py`
- Related tests: none detected
- Search terms: `move`
- Routes: `POST /{game_id}/moves/ai`, `POST /{game_id}/moves/human`
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

## Task Search Recipes

### Fix API Behavior

1. Open the matching file in API Routes or Route Implementation Chains.
2. Follow the listed imports into shared `src/lib/`, database, schema, or validation files.
3. Open the nearest related test from Feature Map or Route Implementation Chains.
4. Broaden to whole-repo search only after route, schema, storage, and tests are checked.

### Fix UI Behavior

1. Start from the matching `src/app/<feature>/page.*` or sibling component in Feature Map.
2. Search inside that feature folder and matching `src/lib/<feature>/` before shared modules.
3. Check API calls and route handlers before editing shared database code.
4. Avoid global styles/assets unless the task is visual or layout-specific.

### Fix Env Or Deployment Issue

1. Open `.env.example` if present.
2. Open env/config files from Key Files or Feature Map.
3. Check deployment docs, migrations, and package scripts.
4. Avoid unrelated feature files unless they reference the specific env var.

## Route Implementation Chains

- `GET /_backend/api/health`
  - Follow:
    - `backend/app/main.py`
- `GET /_backend/health`
  - Follow:
    - `backend/app/main.py`
- `GET /api/health`
  - Follow:
    - `backend/app/main.py`
- `GET /health`
  - Follow:
    - `backend/app/main.py`
- `GET /{game_id}`
  - Follow:
    - `backend/app/api/routes/games.py`
- `POST /{game_id}/moves/ai`
  - Follow:
    - `backend/app/api/routes/games.py`
- `POST /{game_id}/moves/human`
  - Follow:
    - `backend/app/api/routes/games.py`

## Agent Search Guide

- Read first:
  - `package.json` - Node package manifest and scripts
  - `README.md` - Project documentation
  - `frontend/tests/smoke.spec.ts`
  - `backend/app/api/routes/games.py` - API route handler
  - `vercel.json` - Vercel deployment config
  - `backend/app/main.py` - Health endpoint implementation
  - `scripts/smoke-production.mjs` - Operational validation script
- Search by directory role:
  - `backend/` - Backend service
  - `backend/app/` - Backend application code
  - `backend/app/api/` - Backend API routes
  - `frontend/` - Frontend app
  - `frontend/src/` - Frontend source code
  - `scripts/` - Operational scripts/tooling
- Inspect dependency hubs before leaf files:
  - `frontend/src/App.tsx` - imports 7 internal file(s), imported by 1 internal file(s)
  - `frontend/src/games/connect4/types.ts` - imports 0 internal file(s), imported by 7 internal file(s)
  - `frontend/src/api/games.ts` - imports 1 internal file(s), imported by 1 internal file(s)
  - `frontend/src/components/ConnectFourBoard.tsx` - imports 1 internal file(s), imported by 1 internal file(s)
  - `frontend/src/components/ReversiBoard.tsx` - imports 1 internal file(s), imported by 1 internal file(s)

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For API behavior, start from the API Routes section and follow imports from each route file.
- For configuration questions, inspect the Environment Variables section before opening env-related files.
- For expected behavior, use the Tests section to find representative test files and scripts.
- For risk review, start with Findings; each item names the category and usually the relevant file.

## Changes Since Previous Snapshot

- Previous snapshot: `20260625-025320`
- Current generated: `2026-06-25 03:04:03`
- Audit status: `not run` -> `not run`

- No deterministic changes were detected since the previous snapshot.

- Added routes: none
- Removed routes: none
- Added env vars: none
- Removed env vars: none
- Added findings: none
- Resolved findings: none
- Stack changes: none
- Framework changes: none
- Database changes: none
- Test signal changes: none
- Deployment signal changes: none
- Key file changes: none

## Detected Stack

- Languages: Python, TypeScript, JavaScript
- Frameworks: FastAPI, React, Vite, Node.js
- Libraries: none detected
- Databases: none detected
- Testing: Playwright
- Deployment: Vercel

## Project Structure

- `backend/` — Backend service. 25 files scanned.
- `backend/app/` — Backend application code. 11 files scanned.
- `backend/app/api/` — Backend API routes. 3 files scanned.
- `frontend/` — Frontend app. 21 files scanned.
- `frontend/src/` — Frontend source code. 11 files scanned.
- `scripts/` — Operational scripts/tooling. 2 files scanned.
- `docs/` — Documentation. 1 files scanned.

## Key Files

- `README.md` — Project documentation.
- `backend/app/main.py` — Health endpoint implementation.
- `package.json` — Node package manifest and scripts.
- `vercel.json` — Vercel deployment config.
- `backend/app/api/routes/games.py` — API route handler.
- `scripts/smoke-production.mjs` — Operational validation script.

## File Connections

- `frontend/src/App.tsx` — frontend entrypoint/component; Coordinates several internal modules; imports 7 internal file(s), imported by 1 internal file(s).
- `frontend/src/games/connect4/types.ts` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 7 internal file(s).
- `frontend/src/api/games.ts` — source file; Connected to the internal dependency graph; imports 1 internal file(s), imported by 1 internal file(s).
- `frontend/src/components/ConnectFourBoard.tsx` — source file; Connected to the internal dependency graph; imports 1 internal file(s), imported by 1 internal file(s).
- `frontend/src/components/ReversiBoard.tsx` — source file; Connected to the internal dependency graph; imports 1 internal file(s), imported by 1 internal file(s).
- `frontend/src/components/TicTacToeBoard.tsx` — source file; Connected to the internal dependency graph; imports 1 internal file(s), imported by 1 internal file(s).
- `frontend/src/games/registry.ts` — source file; Connected to the internal dependency graph; imports 1 internal file(s), imported by 1 internal file(s).
- `frontend/src/lib/gameCopy.ts` — source file; Connected to the internal dependency graph; imports 1 internal file(s), imported by 1 internal file(s).
- `frontend/src/main.tsx` — frontend entrypoint/component; Connected to the internal dependency graph; imports 1 internal file(s), imported by 0 internal file(s).
- `scripts/smoke-production.mjs` — operational validation script; Connected to the internal dependency graph; imports 0 internal file(s), imported by 0 internal file(s).

## Important Exports

- `backend/app/api/routes/games.py`
  - `create_game` (function)
  - `get_game` (function)
  - `make_ai_move` (function)
  - `make_human_move` (function)
- `backend/app/main.py`
  - `api_healthcheck` (function)
  - `health_payload` (function)
  - `healthcheck` (function)
  - `prefixed_api_healthcheck` (function)
  - `prefixed_healthcheck` (function)
- `backend/app/services/ai_service.py`
  - `AIService` (class)
- `backend/app/services/game_manager.py`
  - `GameEngine` (class)
  - `GameSession` (class)
  - `InMemoryGameStore` (class)
- `backend/app/schemas/game.py`
  - `AIMetadata` (class)
  - `BoardCell` (class)
  - `ErrorResponse` (class)
  - `GameStateResponse` (class)
  - `HistoryMove` (class)
  - `MoveRequest` (class)
  - `MoveResponse` (class)
  - `NewGameRequest` (class)
- `frontend/src/api/games.ts`
  - `createGame` (function)
  - `makeAiMove` (function)
  - `makeHumanCellMove` (function)
  - `makeHumanMove` (function)
- `backend/app/config.py`
  - `Settings` (class)
  - `get_settings` (function)
- `backend/game/ai.py`
  - `choose_ai_move` (function)
  - `game_cols` (function)
  - `game_rows` (function)
  - `get_random_ai_move` (function)
- `backend/game/connect4.py`
  - `ConnectFour` (class)
- `backend/game/reversi.py`
  - `Reversi` (class)
- `backend/game/reversi_ai.py`
  - `choose_reversi_ai_move` (function)
  - `label_move` (function)
- `backend/game/tictactoe.py`
  - `TicTacToe` (class)

## Recommended Next Steps

- **medium / package**: Add a build script if this project needs a production bundle.
- **low / tests**: Add a test script that runs the configured test framework.
- **low / package**: Add a lint script for local and CI readiness.
- **low / tests**: Add a test script so tests are easy to run locally and in CI.
