# StackIndex Full Repo Index

Generated: 2026-06-25 02:53:20

This is the verbose companion to `repo-index.md`. Use it when the compact search plan is not enough.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `opgg`
- Path: `/Users/will/Workspace/opgg`
- Files indexed: 7
- Finding summary: 0 high, 0 medium, 2 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 3
- Large files skipped: 0
- Binary files skipped: 0
- Unresolved internal imports: 0
- Internal alias imports resolved: 0

## Feature Map Quality

- Feature map confidence: low
- Reason: Feature Map has fewer than 2 useful compact features; use Agent Search Guide and Key Files first.
- Start with Agent Search Guide and Key Files before broad searches.

## Project Context

- Likely purpose: Frontend web application
- Confidence: low
- README title: Local.GG
- README summary: A local OP.GG-style League of Legends stats dashboard. It currently uses mock data only, so it runs without a Riot API key or external requests.
- Evidence:

  - README/package metadata suggests a broad project type, but no specific domain category had strong evidence.

## Task Search Recipes

### Fix UI Behavior

1. Start from the matching `src/app/<feature>/page.*` or sibling component in Feature Map.
2. Search inside that feature folder and matching `src/lib/<feature>/` before shared modules.
3. Check API calls and route handlers before editing shared database code.
4. Avoid global styles/assets unless the task is visual or layout-specific.

## Agent Search Guide

- Read first:
  - `package.json` - Node package manifest and scripts
  - `README.md` - Project documentation
  - `src/main.jsx` - Frontend application entrypoint
- Search by directory role:
  - `src/` - Frontend/source application code
- Inspect dependency hubs before leaf files:
  - `src/main.jsx` - imports 0 internal file(s), imported by 0 internal file(s)

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For risk review, start with Findings; each item names the category and usually the relevant file.

## Changes Since Previous Snapshot

No previous snapshot yet. Run StackIndex again after another analysis to see changes.

## Detected Stack

- Languages: JavaScript, TypeScript
- Frameworks: Vite, React, Node.js
- Libraries: none detected
- Databases: none detected
- Testing: none detected
- Deployment: none detected

## Project Structure

- `src/` — Frontend/source application code. 2 files scanned.

## Key Files

- `README.md` — Project documentation.
- `package.json` — Node package manifest and scripts.
- `src/main.jsx` — Frontend application entrypoint.

## File Connections

- `src/main.jsx` — frontend application entrypoint; Connected to the internal dependency graph; imports 0 internal file(s), imported by 0 internal file(s).

## Architecture Hints

- This project appears mostly frontend/static based on Vite-style entrypoints and no detected API routes.

## File Overview

- Source files: 1
- Config files: 3
- Test files: 0
- Docs: 1

## Package Scripts

- `build`: `vite build`
- `dev`: `vite --host 127.0.0.1`
- `preview`: `vite preview --host 127.0.0.1`

## Environment Variables

No environment variable usage detected.

## API Routes

No API routes detected.

## Tests

- Test files: no
- Test script: no
- Frameworks: none detected

## Deployment Readiness

- README: yes
- `.env.example`: no
- Dockerfile: no
- Vercel config: no
- Health endpoint: no
- Migration files: no

## Findings

- **low / package**: No lint script found. (`package.json`)
  Recommendation: Add a lint script for local and CI readiness.
- **low / tests**: No obvious test files were found.
  Recommendation: Add a small smoke test or unit test suite for the critical path.

## Recommended Next Steps

- **low / package**: Add a lint script for local and CI readiness.
- **low / tests**: Add a small smoke test or unit test suite for the critical path.
