# StackIndex Full Repo Index

Generated: 2026-06-25 03:04:04

This is the verbose companion to `repo-index.md`. Use it when the compact search plan is not enough.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `stackindex`
- Path: `/Users/will/Workspace/stackindex`
- Files indexed: 108
- Finding summary: 0 high, 1 medium, 2 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 7
- Large files skipped: 0
- Binary files skipped: 1
- Unresolved internal imports: 0
- Internal alias imports resolved: 0
- Confidence warnings:
  - Binary files were skipped.

## Project Context

- Likely purpose: Go CLI/TUI repository analysis tool
- Confidence: high
- README title: StackIndex
- README summary: StackIndex is a local-first repo orientation file generator for coding agents. It creates a compact, deterministic Markdown search plan so agents know where to start, what to avoid, and when to broaden.
- Evidence:

  - README/package metadata points to go cli/tui repository analysis tool.
  - Package scripts include desktop/frontend:build, desktop/frontend:dev.
  - Repository structure includes cmd/ for cli entrypoints.

## Feature Map

### Frontend

- Start here:
  - `desktop/frontend/index.html`
  - `desktop/frontend/package.json`
  - `desktop/frontend/src/App.tsx`
  - `desktop/frontend/src/components/AppShell.tsx`
  - `desktop/frontend/src/components/LandingPage.tsx`
  - `desktop/frontend/src/components/MetricCard.tsx`
  - `desktop/frontend/src/components/ReportPath.tsx`
  - `desktop/frontend/src/components/ReportWorkspace.tsx`
  - `desktop/frontend/src/components/SettingsPage.tsx`
  - `desktop/frontend/src/components/Sidebar.tsx`
  - `desktop/frontend/src/components/StackChip.tsx`
  - `desktop/frontend/src/components/StatusBadge.tsx`
  - `desktop/frontend/src/components/sections.ts`
  - `desktop/frontend/src/main.tsx`
  - `desktop/frontend/src/wails.ts`
  - `desktop/frontend/tsconfig.json`
  - `desktop/frontend/vite.config.ts`
  - `desktop/frontend/wailsjs/go/main/App.d.ts`
  - `desktop/frontend/wailsjs/go/main/App.js`
  - `desktop/frontend/wailsjs/go/models.ts`
  - `desktop/frontend/wailsjs/runtime/package.json`
  - `desktop/frontend/wailsjs/runtime/runtime.d.ts`
  - `desktop/frontend/wailsjs/runtime/runtime.js`
- Related tests: none detected
- Search terms: `frontend`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Backend

- Start here:
  - `desktop/backend/analysis.go`
  - `desktop/backend/github.go`
  - `desktop/backend/recent.go`
  - `desktop/backend/report_actions.go`
  - `desktop/backend/settings.go`
- Related tests:
  - `desktop/backend/analysis_integration_test.go`
  - `desktop/backend/analysis_test.go`
  - `desktop/backend/github_test.go`
  - `desktop/backend/recent_test.go`
  - `desktop/backend/report_actions_test.go`
  - `desktop/backend/settings_test.go`
- Search terms: `backend`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Report

- Start here:
  - `internal/report/agents.go`
  - `internal/report/changes.go`
  - `internal/report/gitignore.go`
  - `internal/report/history.go`
  - `internal/report/json.go`
  - `internal/report/markdown.go`
  - `internal/report/staleness.go`
- Related tests:
  - `internal/report/changes_test.go`
  - `internal/report/gitignore_test.go`
  - `internal/report/history_test.go`
  - `internal/report/json_test.go`
  - `internal/report/markdown_test.go`
- Search terms: `report`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Tui

- Start here:
  - `internal/tui/app.go`
  - `internal/tui/screens/findings.go`
  - `internal/tui/screens/home.go`
  - `internal/tui/screens/report.go`
  - `internal/tui/screens/routes.go`
  - `internal/tui/styles.go`
- Related tests:
  - `internal/tui/app_test.go`
- Search terms: `tui`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

### Scanner

- Start here:
  - `internal/scanner/classify.go`
  - `internal/scanner/ignore.go`
  - `internal/scanner/walk.go`
- Related tests:
  - `internal/scanner/ignore_test.go`
- Search terms: `scanner`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

## Task Search Recipes

### Fix UI Behavior

1. Start from the matching `src/app/<feature>/page.*` or sibling component in Feature Map.
2. Search inside that feature folder and matching `src/lib/<feature>/` before shared modules.
3. Check API calls and route handlers before editing shared database code.
4. Avoid global styles/assets unless the task is visual or layout-specific.

## Agent Search Guide

- Read first:
  - `README.md` - Project documentation
  - `desktop/README.md` - Project documentation
  - `desktop/frontend/vite.config.ts` - Vite config
  - `cmd/stackindex/main.go` - Main CLI entrypoint
  - `go.mod` - Go module definition
- Search by directory role:
  - `cmd/` - CLI entrypoints
  - `internal/` - Internal application packages
  - `scripts/` - Operational scripts/tooling
- Inspect dependency hubs before leaf files:
  - `internal/models/analysis.go` - imports 0 internal file(s), imported by 49 internal file(s)
  - `desktop/frontend/src/components/ReportWorkspace.tsx` - imports 7 internal file(s), imported by 1 internal file(s)
  - `internal/app/app.go` - imports 6 internal file(s), imported by 2 internal file(s)
  - `cmd/stackindex/main.go` - imports 7 internal file(s), imported by 0 internal file(s)
  - `desktop/frontend/src/App.tsx` - imports 5 internal file(s), imported by 1 internal file(s)

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For expected behavior, use the Tests section to find representative test files and scripts.
- For risk review, start with Findings; each item names the category and usually the relevant file.

## Changes Since Previous Snapshot

- Previous snapshot: `20260625-025321`
- Current generated: `2026-06-25 03:04:04`
- Audit status: `not run` -> `not run`

- No deterministic changes were detected since the previous snapshot.

- Added routes: none
- Removed routes: none
- Added env vars: none
- Removed env vars: none
- Added findings: none
- Resolved findings: none
- Stack changes: none
- Framework changes: none
- Database changes: none
- Test signal changes: none
- Deployment signal changes: none
- Key file changes: none

## Detected Stack

- Languages: Go, TypeScript, JavaScript
- Frameworks: Vite, React, Node.js
- Libraries: none detected
- Databases: none detected
- Testing: none detected
- Deployment: none detected

## Project Structure

- `cmd/` — CLI entrypoints. 2 files scanned.
- `internal/` — Internal application packages. 55 files scanned.
- `scripts/` — Operational scripts/tooling. 1 files scanned.

## Key Files

- `README.md` — Project documentation.
- `cmd/stackindex/main.go` — Main CLI entrypoint.
- `desktop/README.md` — Project documentation.
- `desktop/frontend/vite.config.ts` — Vite config.
- `go.mod` — Go module definition.

## File Connections

- `internal/models/analysis.go` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 49 internal file(s).
- `desktop/frontend/src/components/ReportWorkspace.tsx` — source file; Coordinates several internal modules; imports 7 internal file(s), imported by 1 internal file(s).
- `internal/app/app.go` — source file; Shared module imported by multiple files; imports 6 internal file(s), imported by 2 internal file(s).
- `cmd/stackindex/main.go` — main CLI entrypoint; Entrypoint that connects to other project modules; imports 7 internal file(s), imported by 0 internal file(s).
- `desktop/frontend/src/App.tsx` — frontend entrypoint/component; Coordinates several internal modules; imports 5 internal file(s), imported by 1 internal file(s).
- `desktop/backend/analysis.go` — source file; Coordinates several internal modules; imports 4 internal file(s), imported by 1 internal file(s).
- `internal/qa/qa.go` — source file; Shared module imported by multiple files; imports 2 internal file(s), imported by 3 internal file(s).
- `internal/report/agents.go` — source file; Shared module imported by multiple files; imports 1 internal file(s), imported by 4 internal file(s).
- `internal/scanner/classify.go` — source file; Shared module imported by multiple files; imports 1 internal file(s), imported by 4 internal file(s).
- `desktop/frontend/src/wails.ts` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 4 internal file(s).

## Important Exports

- `desktop/backend/analysis.go`
  - `AnalyzeProject` (function)
  - `BuildAnalyzeResponse` (function)
  - `BuildAskResponse` (function)
  - `ListOllamaModels` (function)
  - `NewSession` (function)
  - `AnalyzeProject` (method)
  - `AskQuestion` (method)
  - `ListOllamaModels` (method)
- `desktop/frontend/src/components/ReportWorkspace.tsx`
  - `ReportWorkspace` (function)
- `desktop/frontend/src/wails.ts`
  - `analyzeGitHubRepo` (function)
  - `analyzeProject` (function)
  - `browseFolder` (function)
  - `clearGitHubCache` (function)
  - `clearRecentProjects` (function)
  - `generateCLICommand` (function)
  - `getDesktopPaths` (function)
  - `getDesktopSettings` (function)
- `internal/report/agents.go`
  - `AgentsMarkdown` (function)
  - `WriteAgentsMD` (function)
  - `AgentsOptions` (type)
- `internal/scanner/classify.go`
  - `Classify` (function)
- `desktop/backend/github.go`
  - `AnalyzeGitHubRepo` (method)
  - `Run` (method)
  - `GitHubAnalyzeRequest` (type)
- `desktop/backend/recent.go`
  - `ClearRecentProjects` (method)
  - `GetRecentProjects` (method)
  - `RemoveRecentProject` (method)
  - `RecentProject` (type)
- `desktop/backend/report_actions.go`
  - `GenerateCLICommand` (method)
  - `OpenJSONReport` (method)
  - `OpenMarkdownReport` (method)
  - `ReadGeneratedFile` (method)
  - `RevealProjectFolder` (method)
  - `RevealSnapshotFolder` (method)
  - `RevealStackIndexFolder` (method)
  - `CLICommandRequest` (type)
- `desktop/backend/settings.go`
  - `ClearGitHubCache` (method)
  - `GetDesktopPaths` (method)
  - `GetDesktopSettings` (method)
  - `SaveDesktopSettings` (method)
  - `DesktopPaths` (type)
  - `DesktopSettings` (type)
- `desktop/frontend/src/components/AppShell.tsx`
  - `AppShell` (function)
- `desktop/frontend/src/components/LandingPage.tsx`
  - `LandingPage` (function)
- `desktop/frontend/src/components/MetricCard.tsx`
  - `MetricCard` (function)

## Architecture Hints

- Shared modules are imported by multiple important files.

## File Overview

- Source files: 65
- Config files: 7
- Test files: 25
- Docs: 3

## Package Scripts

- `desktop/frontend:build`: `tsc && vite build`
- `desktop/frontend:dev`: `vite --host 127.0.0.1`
- `desktop/frontend:preview`: `vite preview --host 127.0.0.1`

## Environment Variables

No environment variable usage detected.

## API Routes

No API routes detected.

## Tests

- Test files: yes
- Test script: no
- Frameworks: none detected

## Deployment Readiness

- README: yes
- `.env.example`: no
- Dockerfile: no
- Vercel config: no
- Health endpoint: no
- Migration files: no

## Findings

- **medium / package**: No build script found. (`package.json`)
  Recommendation: Add a build script if this project needs a production bundle.
- **low / package**: No lint script found. (`package.json`)
  Recommendation: Add a lint script for local and CI readiness.
- **low / tests**: Test files exist, but no package test script was found. (`package.json`)
  Recommendation: Add a test script so tests are easy to run locally and in CI.

## Recommended Next Steps

- **medium / package**: Add a build script if this project needs a production bundle.
- **low / package**: Add a lint script for local and CI readiness.
- **low / tests**: Add a test script so tests are easy to run locally and in CI.
