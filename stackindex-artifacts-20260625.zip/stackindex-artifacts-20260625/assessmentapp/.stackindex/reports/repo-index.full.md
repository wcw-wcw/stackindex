# StackIndex Full Repo Index

Generated: 2026-06-25 02:53:20

This is the verbose companion to `repo-index.md`. Use it when the compact search plan is not enough.

## Agent Usage Instructions

- Read this file before broad searches.
- Use Feature Map for feature work.
- Use Route Implementation Chains for API work.
- Use Task Search Recipes before searching the whole repo.
- Open `repo-index.full.md` only when compact output is insufficient.
- Avoid generated/cache folders such as `.stackindex/`, `node_modules/`, `dist/`, `build/`, and framework caches.

## Repository Snapshot

- Repository: `assessmentapp`
- Path: `/Users/will/Workspace/assessmentapp`
- Files indexed: 44
- Finding summary: 0 high, 2 medium, 2 low, 0 info

## Index Freshness

- Index stale: no
- Changed file count: 0

## Index Quality

- Generated/cache folders ignored: yes
- Ignored generated/cache directories: 4
- Large files skipped: 0
- Binary files skipped: 2
- Unresolved internal imports: 0
- Internal alias imports resolved: 0
- Confidence warnings:
  - Binary files were skipped.

## Feature Map Quality

- Feature map confidence: low
- Reason: Feature Map has fewer than 2 useful compact features; use Agent Search Guide and Key Files first.
- Start with Agent Search Guide and Key Files before broad searches.

## Project Context

- Likely purpose: Assessment/education application
- Confidence: high
- README title: AssessmentHub
- README summary: AssessmentHub is a small assessment-taking app for creating multiple-choice assessments, publishing them to students, collecting submissions, and showing instant scores.
- Evidence:

  - README/package metadata points to assessment/education application.
  - Package scripts include backend:dev, backend:start, build, dev:api.
  - Environment variable names include DATABASE_PATH, PORT.
  - Repository structure includes backend/ for backend service.

## Feature Map

### Teacher

- Start here:
  - `frontend/src/pages/teacher/NewAssessmentPage.tsx`
  - `frontend/src/pages/teacher/TeacherAssessmentPage.tsx`
  - `frontend/src/pages/teacher/TeacherAttemptPage.tsx`
  - `frontend/src/pages/teacher/TeacherDashboardPage.tsx`
- Related tests: none detected
- Search terms: `teacher`
- Routes: none
- Avoid first: `generated reports`, `global styles/assets`, `lockfiles`, `build/cache folders`
- Confidence: medium

## Task Search Recipes

### Fix UI Behavior

1. Start from the matching `src/app/<feature>/page.*` or sibling component in Feature Map.
2. Search inside that feature folder and matching `src/lib/<feature>/` before shared modules.
3. Check API calls and route handlers before editing shared database code.
4. Avoid global styles/assets unless the task is visual or layout-specific.

### Fix Env Or Deployment Issue

1. Open `.env.example` if present.
2. Open env/config files from Key Files or Feature Map.
3. Check deployment docs, migrations, and package scripts.
4. Avoid unrelated feature files unless they reference the specific env var.

## Agent Search Guide

- Read first:
  - `package.json` - Node package manifest and scripts
  - `README.md` - Project documentation
  - `frontend/README.md` - Project documentation
  - `frontend/vite.config.ts` - Vite config
- Search by directory role:
  - `backend/` - Backend service
  - `frontend/` - Frontend app
  - `frontend/src/` - Frontend source code
  - `database/` - Database schema/migrations
  - `docs/` - Documentation
- Inspect dependency hubs before leaf files:
  - `frontend/src/components/AppLayout.tsx` - imports 2 internal file(s), imported by 8 internal file(s)
  - `frontend/src/types/assessment.ts` - imports 0 internal file(s), imported by 10 internal file(s)
  - `frontend/src/App.tsx` - imports 8 internal file(s), imported by 1 internal file(s)
  - `frontend/src/components/Card.tsx` - imports 0 internal file(s), imported by 8 internal file(s)
  - `frontend/src/data/api.ts` - imports 1 internal file(s), imported by 7 internal file(s)

## Search Budget Hints

- Prefer symbol/path searches inside the key directories above before scanning the whole repo.
- For configuration questions, inspect the Environment Variables section before opening env-related files.
- For risk review, start with Findings; each item names the category and usually the relevant file.

## Changes Since Previous Snapshot

No previous snapshot yet. Run StackIndex again after another analysis to see changes.

## Detected Stack

- Languages: JavaScript, TypeScript
- Frameworks: Vite, React, Tailwind CSS, Node.js
- Libraries: none detected
- Databases: none detected
- Testing: none detected
- Deployment: none detected

## Project Structure

- `backend/` — Backend service. 3 files scanned.
- `frontend/` — Frontend app. 34 files scanned.
- `frontend/src/` — Frontend source code. 22 files scanned.
- `database/` — Database schema/migrations. 2 files scanned.
- `docs/` — Documentation. 2 files scanned.

## Key Files

- `README.md` — Project documentation.
- `frontend/README.md` — Project documentation.
- `frontend/vite.config.ts` — Vite config.
- `package.json` — Node package manifest and scripts.

## File Connections

- `frontend/src/components/AppLayout.tsx` — source file; Shared module imported by multiple files; imports 2 internal file(s), imported by 8 internal file(s).
- `frontend/src/types/assessment.ts` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 10 internal file(s).
- `frontend/src/App.tsx` — frontend entrypoint/component; Coordinates several internal modules; imports 8 internal file(s), imported by 1 internal file(s).
- `frontend/src/components/Card.tsx` — source file; Shared module imported by multiple files; imports 0 internal file(s), imported by 8 internal file(s).
- `frontend/src/data/api.ts` — source file; Shared module imported by multiple files; imports 1 internal file(s), imported by 7 internal file(s).
- `frontend/src/pages/teacher/TeacherAssessmentPage.tsx` — source file; Coordinates several internal modules; imports 5 internal file(s), imported by 1 internal file(s).
- `frontend/src/pages/teacher/TeacherDashboardPage.tsx` — source file; Coordinates several internal modules; imports 5 internal file(s), imported by 1 internal file(s).
- `frontend/src/pages/student/StudentDashboardPage.tsx` — source file; Coordinates several internal modules; imports 4 internal file(s), imported by 1 internal file(s).
- `frontend/src/pages/student/StudentResultsPage.tsx` — source file; Coordinates several internal modules; imports 4 internal file(s), imported by 1 internal file(s).
- `frontend/src/pages/student/TakeAssessmentPage.tsx` — source file; Coordinates several internal modules; imports 4 internal file(s), imported by 1 internal file(s).

## Important Exports

- `frontend/src/data/api.ts`
  - `api` (value)
- `frontend/src/types/assessment.ts`
  - `AnswerChoice` (type)
  - `Assessment` (type)
  - `AssessmentStatus` (type)
  - `Attempt` (type)
  - `AttemptQuestion` (type)
  - `AttemptStatus` (type)
  - `AttemptSummary` (type)
  - `CreateAssessmentPayload` (type)

## Architecture Hints

- Shared modules are imported by multiple important files.

## File Overview

- Source files: 22
- Config files: 11
- Test files: 0
- Docs: 4

## Package Scripts

- `backend:dev`: `node --watch src/server.js`
- `backend:start`: `node src/server.js`
- `build`: `npm --prefix frontend run build`
- `dev:api`: `npm --prefix backend run dev`
- `dev:web`: `npm --prefix frontend run dev`
- `frontend:build`: `tsc -b && vite build`
- `frontend:dev`: `vite`
- `frontend:lint`: `eslint .`
- `frontend:preview`: `vite preview`
- `start`: `npm --prefix backend start`

## Environment Variables

- `.env.example`: no

- Required app config: `DATABASE_PATH` (missing from `.env.example`)
- Optional app config: none detected
- Platform/build metadata: `PORT` (detected but likely platform/build provided)
- Script-only vars: none detected
- Missing required from .env.example: `DATABASE_PATH`

## API Routes

No API routes detected.

## Tests

- Test files: no
- Test script: no
- Frameworks: none detected

## Deployment Readiness

- README: yes
- `.env.example`: no
- Dockerfile: no
- Vercel config: no
- Health endpoint: no
- Migration files: no

## Findings

- **low / package**: No lint script found. (`package.json`)
  Recommendation: Add a lint script for local and CI readiness.
- **medium / env**: Environment variables are used, but no .env.example file was found.
  Recommendation: Add a .env.example with variable names and safe placeholder values.
- **low / tests**: No obvious test files were found.
  Recommendation: Add a small smoke test or unit test suite for the critical path.
- **medium / deployment**: Environment variables are used but not documented in .env.example.
  Recommendation: Add .env.example before deployment handoff.

## Recommended Next Steps

- **medium / env**: Add a .env.example with variable names and safe placeholder values.
- **medium / deployment**: Add .env.example before deployment handoff.
- **low / package**: Add a lint script for local and CI readiness.
- **low / tests**: Add a small smoke test or unit test suite for the critical path.
